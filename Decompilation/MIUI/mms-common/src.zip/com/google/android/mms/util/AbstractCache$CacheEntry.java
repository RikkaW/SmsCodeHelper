package com.google.android.mms.util;

class AbstractCache$CacheEntry<V>
{
  int hit;
  V value;
}

/* Location:
 * Qualified Name:     com.google.android.mms.util.AbstractCache.CacheEntry
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */