package com.google.android.mms;

public class InvalidHeaderValueException
  extends MmsException
{
  private static final long serialVersionUID = -2053384496042052262L;
  
  public InvalidHeaderValueException() {}
  
  public InvalidHeaderValueException(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     com.google.android.mms.InvalidHeaderValueException
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */