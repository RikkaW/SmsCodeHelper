package org.w3c.dom.events;

public abstract interface EventListener
{
  public abstract void handleEvent(Event paramEvent);
}

/* Location:
 * Qualified Name:     org.w3c.dom.events.EventListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */