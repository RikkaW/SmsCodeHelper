package org.w3c.dom.events;

public abstract interface Event
{
  public abstract String getType();
  
  public abstract void initEvent(String paramString, boolean paramBoolean1, boolean paramBoolean2);
}

/* Location:
 * Qualified Name:     org.w3c.dom.events.Event
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */