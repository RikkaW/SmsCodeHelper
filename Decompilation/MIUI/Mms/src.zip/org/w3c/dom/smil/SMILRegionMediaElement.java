package org.w3c.dom.smil;

public abstract interface SMILRegionMediaElement
  extends SMILMediaElement, SMILRegionInterface
{}

/* Location:
 * Qualified Name:     org.w3c.dom.smil.SMILRegionMediaElement
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */