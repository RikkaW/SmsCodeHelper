package org.w3c.dom.smil;

public abstract interface TimeList
{
  public abstract int getLength();
  
  public abstract Time item(int paramInt);
}

/* Location:
 * Qualified Name:     org.w3c.dom.smil.TimeList
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */