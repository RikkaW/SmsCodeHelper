package org.w3c.dom.smil;

public abstract interface SMILParElement
  extends ElementParallelTimeContainer, SMILElement
{}

/* Location:
 * Qualified Name:     org.w3c.dom.smil.SMILParElement
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */