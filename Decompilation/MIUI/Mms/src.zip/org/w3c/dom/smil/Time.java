package org.w3c.dom.smil;

public abstract interface Time
{
  public abstract double getOffset();
  
  public abstract boolean getResolved();
  
  public abstract double getResolvedOffset();
  
  public abstract short getTimeType();
}

/* Location:
 * Qualified Name:     org.w3c.dom.smil.Time
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */