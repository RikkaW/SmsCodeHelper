package miui.external;

abstract interface SdkConstants
{
  public static enum SdkError
  {
    private SdkError() {}
  }
}

/* Location:
 * Qualified Name:     miui.external.SdkConstants
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */