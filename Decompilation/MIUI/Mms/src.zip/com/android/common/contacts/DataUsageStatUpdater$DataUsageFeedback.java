package com.android.common.contacts;

import android.net.Uri;
import android.provider.ContactsContract.Data;

public final class DataUsageStatUpdater$DataUsageFeedback
{
  static final Uri FEEDBACK_URI = Uri.withAppendedPath(ContactsContract.Data.CONTENT_URI, "usagefeedback");
}

/* Location:
 * Qualified Name:     com.android.common.contacts.DataUsageStatUpdater.DataUsageFeedback
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */