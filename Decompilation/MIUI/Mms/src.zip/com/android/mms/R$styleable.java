package com.android.mms;

public final class R$styleable
{
  public static final int[] EditableListView = { 2130771971, 2130771972, 2130771973 };
  public static final int[] RecordingProgressView = { 2130771974, 2130771975, 2130771976, 2130771977, 2130771978, 2130771979 };
  public static final int[] RowLayout = { 2130771969, 2130771970 };
  public static final int[] ShrinkableLinearLayout = { 2130771968 };
}

/* Location:
 * Qualified Name:     com.android.mms.R.styleable
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */