package com.android.mms.dom.smil;

import org.w3c.dom.smil.ElementTimeContainer;
import org.w3c.dom.smil.SMILElement;

public abstract class ElementTimeContainerImpl
  extends ElementTimeImpl
  implements ElementTimeContainer
{
  ElementTimeContainerImpl(SMILElement paramSMILElement)
  {
    super(paramSMILElement);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.dom.smil.ElementTimeContainerImpl
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */