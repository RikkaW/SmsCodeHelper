package com.android.mms.dom.smil;

import org.w3c.dom.smil.SMILRefElement;

public class SmilRefElementImpl
  extends SmilRegionMediaElementImpl
  implements SMILRefElement
{
  SmilRefElementImpl(SmilDocumentImpl paramSmilDocumentImpl, String paramString)
  {
    super(paramSmilDocumentImpl, paramString);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.dom.smil.SmilRefElementImpl
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */