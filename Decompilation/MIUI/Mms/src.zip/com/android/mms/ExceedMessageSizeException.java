package com.android.mms;

public final class ExceedMessageSizeException
  extends ContentRestrictionException
{
  private static final long serialVersionUID = 6647713416796190850L;
  
  public ExceedMessageSizeException() {}
  
  public ExceedMessageSizeException(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ExceedMessageSizeException
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */