package com.android.mms.backup;

import com.google.protobuf.MessageLiteOrBuilder;

public abstract interface MmsProtos$PduAddrOrBuilder
  extends MessageLiteOrBuilder
{}

/* Location:
 * Qualified Name:     com.android.mms.backup.MmsProtos.PduAddrOrBuilder
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */