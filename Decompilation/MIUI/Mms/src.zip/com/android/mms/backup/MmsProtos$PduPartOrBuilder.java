package com.android.mms.backup;

import com.google.protobuf.MessageLiteOrBuilder;

public abstract interface MmsProtos$PduPartOrBuilder
  extends MessageLiteOrBuilder
{}

/* Location:
 * Qualified Name:     com.android.mms.backup.MmsProtos.PduPartOrBuilder
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */