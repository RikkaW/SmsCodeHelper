package com.android.mms.backup;

class SyncRootProtos$1 {}

/* Location:
 * Qualified Name:     com.android.mms.backup.SyncRootProtos.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */