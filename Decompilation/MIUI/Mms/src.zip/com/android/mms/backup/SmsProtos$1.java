package com.android.mms.backup;

class SmsProtos$1 {}

/* Location:
 * Qualified Name:     com.android.mms.backup.SmsProtos.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */