package com.android.mms;

public class ContentRestrictionException
  extends RuntimeException
{
  private static final long serialVersionUID = 516136015813043499L;
  
  public ContentRestrictionException() {}
  
  public ContentRestrictionException(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ContentRestrictionException
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */