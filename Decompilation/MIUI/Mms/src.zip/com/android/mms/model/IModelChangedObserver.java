package com.android.mms.model;

public abstract interface IModelChangedObserver
{
  public abstract void onModelChanged(Model paramModel, boolean paramBoolean);
}

/* Location:
 * Qualified Name:     com.android.mms.model.IModelChangedObserver
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */