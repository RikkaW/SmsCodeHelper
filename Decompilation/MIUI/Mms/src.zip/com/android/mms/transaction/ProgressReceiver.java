package com.android.mms.transaction;

public abstract interface ProgressReceiver
{
  public abstract void onProgress(long paramLong1, long paramLong2);
}

/* Location:
 * Qualified Name:     com.android.mms.transaction.ProgressReceiver
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */