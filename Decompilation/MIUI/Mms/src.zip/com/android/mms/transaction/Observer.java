package com.android.mms.transaction;

public abstract interface Observer
{
  public abstract void update(Observable paramObservable);
}

/* Location:
 * Qualified Name:     com.android.mms.transaction.Observer
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */