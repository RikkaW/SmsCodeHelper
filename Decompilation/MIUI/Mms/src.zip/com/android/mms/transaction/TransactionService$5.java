package com.android.mms.transaction;

class TransactionService$5
  implements Runnable
{
  TransactionService$5(TransactionService paramTransactionService, int paramInt, TransactionBundle paramTransactionBundle) {}
  
  public void run()
  {
    TransactionService.access$902(this$0, val$startId);
    TransactionService.access$1100(this$0, val$args);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.transaction.TransactionService.5
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */