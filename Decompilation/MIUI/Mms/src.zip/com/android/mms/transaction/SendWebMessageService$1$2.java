package com.android.mms.transaction;

class SendWebMessageService$1$2
  implements Runnable
{
  SendWebMessageService$1$2(SendWebMessageService.1 param1, String paramString) {}
  
  public void run()
  {
    SendWebMessageService.access$000(this$1.this$0, val$address, false, 0);
    SendWebMessageService.access$000(this$1.this$0, val$address, false, 1);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.transaction.SendWebMessageService.1.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */