package com.android.mms.transaction;

class SendWebMessageService$3
  implements Runnable
{
  SendWebMessageService$3(SendWebMessageService paramSendWebMessageService, String paramString, int paramInt) {}
  
  public void run()
  {
    SendWebMessageService.access$000(this$0, val$address, false, val$slotId);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.transaction.SendWebMessageService.3
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */