package com.android.mms.transaction;

import android.widget.Toast;

class SmsReceiverService$2
  implements Runnable
{
  SmsReceiverService$2(SmsReceiverService paramSmsReceiverService) {}
  
  public void run()
  {
    Toast.makeText(this$0, this$0.getString(2131362001), 0).show();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.transaction.SmsReceiverService.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */