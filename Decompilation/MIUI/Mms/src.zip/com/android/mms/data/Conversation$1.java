package com.android.mms.data;

import android.content.Context;

final class Conversation$1
  implements Runnable
{
  Conversation$1(Context paramContext) {}
  
  public void run()
  {
    Conversation.access$200(val$context);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.data.Conversation.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */