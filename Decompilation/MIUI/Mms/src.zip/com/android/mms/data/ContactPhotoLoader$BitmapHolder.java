package com.android.mms.data;

import android.graphics.Bitmap;
import java.lang.ref.SoftReference;

class ContactPhotoLoader$BitmapHolder
{
  SoftReference<Bitmap> bitmapRef;
  int state;
}

/* Location:
 * Qualified Name:     com.android.mms.data.ContactPhotoLoader.BitmapHolder
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */