package com.android.mms.data;

class FestivalUpdater$JSONContentException
  extends Exception
{
  private static final long serialVersionUID = 1L;
}

/* Location:
 * Qualified Name:     com.android.mms.data.FestivalUpdater.JSONContentException
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */