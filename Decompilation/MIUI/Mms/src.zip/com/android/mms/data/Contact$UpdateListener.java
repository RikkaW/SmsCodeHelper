package com.android.mms.data;

public abstract interface Contact$UpdateListener
{
  public abstract void onUpdate(Contact paramContact);
}

/* Location:
 * Qualified Name:     com.android.mms.data.Contact.UpdateListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */