package com.android.mms.data;

public class RecipientIdCache$Entry
{
  public long id;
  public String number;
  
  public RecipientIdCache$Entry(long paramLong, String paramString)
  {
    id = paramLong;
    number = paramString;
  }
}

/* Location:
 * Qualified Name:     com.android.mms.data.RecipientIdCache.Entry
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */