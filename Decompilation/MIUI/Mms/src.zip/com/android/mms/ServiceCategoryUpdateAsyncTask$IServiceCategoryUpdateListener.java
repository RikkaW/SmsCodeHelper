package com.android.mms;

public abstract interface ServiceCategoryUpdateAsyncTask$IServiceCategoryUpdateListener
{
  public abstract void onUpdateSuccess();
}

/* Location:
 * Qualified Name:     com.android.mms.ServiceCategoryUpdateAsyncTask.IServiceCategoryUpdateListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */