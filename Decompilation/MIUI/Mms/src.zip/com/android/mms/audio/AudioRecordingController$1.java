package com.android.mms.audio;

import com.xiaomi.mms.mx.audio.player.XMAudioRecorder;

class AudioRecordingController$1
  implements Runnable
{
  AudioRecordingController$1(AudioRecordingController paramAudioRecordingController) {}
  
  public void run()
  {
    AudioRecordingController.access$000(this$0).stop();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.audio.AudioRecordingController.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */