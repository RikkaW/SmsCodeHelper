package com.android.mms.audio;

class AudioRecordingController$2
  implements Runnable
{
  AudioRecordingController$2(AudioRecordingController paramAudioRecordingController) {}
  
  public void run()
  {
    AudioRecordingController.access$100(this$0);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.audio.AudioRecordingController.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */