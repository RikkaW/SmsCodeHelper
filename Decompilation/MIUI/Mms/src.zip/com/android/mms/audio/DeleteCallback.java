package com.android.mms.audio;

public abstract interface DeleteCallback
{
  public abstract void onDeleteComplete(int paramInt1, Object paramObject, int paramInt2);
}

/* Location:
 * Qualified Name:     com.android.mms.audio.DeleteCallback
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */