package com.android.mms.util;

import android.view.View;
import android.widget.AdapterView;

public abstract interface EditableListView$OnItemDoubleClickListener
{
  public abstract void onDoubleClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong);
  
  public abstract void onSingleClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong);
}

/* Location:
 * Qualified Name:     com.android.mms.util.EditableListView.OnItemDoubleClickListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */