package com.android.mms.util;

public abstract interface EditableListView$ICheckableAdapter
{
  public abstract boolean allowChecked(int paramInt);
  
  public abstract int getDisableCheckedCount();
}

/* Location:
 * Qualified Name:     com.android.mms.util.EditableListView.ICheckableAdapter
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */