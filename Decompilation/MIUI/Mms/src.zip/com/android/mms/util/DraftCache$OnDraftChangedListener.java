package com.android.mms.util;

public abstract interface DraftCache$OnDraftChangedListener
{
  public abstract void onDraftChanged(long paramLong, boolean paramBoolean);
}

/* Location:
 * Qualified Name:     com.android.mms.util.DraftCache.OnDraftChangedListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */