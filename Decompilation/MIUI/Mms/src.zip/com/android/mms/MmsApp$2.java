package com.android.mms;

import com.android.mms.ui.MessageListItem;
import com.android.mms.ui.ThumbnailView;

class MmsApp$2
  implements Runnable
{
  MmsApp$2(MmsApp paramMmsApp) {}
  
  public void run()
  {
    MessageListItem.initDummy();
    ThumbnailView.initDummy();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.MmsApp.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */