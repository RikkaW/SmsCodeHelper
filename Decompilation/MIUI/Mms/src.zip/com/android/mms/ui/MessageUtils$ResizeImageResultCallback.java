package com.android.mms.ui;

import com.google.android.mms.pdu.PduPart;

abstract interface MessageUtils$ResizeImageResultCallback
{
  public abstract void onResizeResult(PduPart paramPduPart, boolean paramBoolean);
}

/* Location:
 * Qualified Name:     com.android.mms.ui.MessageUtils.ResizeImageResultCallback
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */