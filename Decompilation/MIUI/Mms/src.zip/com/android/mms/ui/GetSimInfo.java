package com.android.mms.ui;

public abstract interface GetSimInfo
{
  public abstract int getSimDisplayIcon(int paramInt);
  
  public abstract String getSimDisplayName(int paramInt);
  
  public abstract String getSimNumber(int paramInt);
}

/* Location:
 * Qualified Name:     com.android.mms.ui.GetSimInfo
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */