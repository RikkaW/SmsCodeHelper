package com.android.mms.ui;

import android.view.View;
import android.view.View.OnClickListener;

class BasicSlideEditorView$1
  implements View.OnClickListener
{
  BasicSlideEditorView$1(BasicSlideEditorView paramBasicSlideEditorView) {}
  
  public void onClick(View paramView)
  {
    if (BasicSlideEditorView.access$000(this$0) != null) {
      BasicSlideEditorView.access$000(this$0).onClick(paramView);
    }
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.BasicSlideEditorView.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */