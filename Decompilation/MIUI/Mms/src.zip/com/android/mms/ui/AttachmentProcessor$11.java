package com.android.mms.ui;

class AttachmentProcessor$11
  implements Runnable
{
  AttachmentProcessor$11(AttachmentProcessor paramAttachmentProcessor) {}
  
  public void run()
  {
    AttachmentProcessor.access$900(this$0);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AttachmentProcessor.11
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */