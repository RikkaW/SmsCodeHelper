package com.android.mms.ui;

class ConfirmRateLimitActivity$3
  implements Runnable
{
  ConfirmRateLimitActivity$3(ConfirmRateLimitActivity paramConfirmRateLimitActivity) {}
  
  public void run()
  {
    ConfirmRateLimitActivity.access$000(this$0, false);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConfirmRateLimitActivity.3
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */