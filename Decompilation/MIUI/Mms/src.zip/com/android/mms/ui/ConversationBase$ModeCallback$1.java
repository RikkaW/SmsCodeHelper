package com.android.mms.ui;

class ConversationBase$ModeCallback$1
  implements Runnable
{
  ConversationBase$ModeCallback$1(ConversationBase.ModeCallback paramModeCallback) {}
  
  public void run()
  {
    this$1.this$0.mMsgListView.setAllowTranscriptOnResize(true);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationBase.ModeCallback.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */