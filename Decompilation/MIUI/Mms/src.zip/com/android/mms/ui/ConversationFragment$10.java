package com.android.mms.ui;

class ConversationFragment$10
  implements Runnable
{
  ConversationFragment$10(ConversationFragment paramConversationFragment) {}
  
  public void run()
  {
    this$0.mListAdapter.notifyDataSetChanged();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationFragment.10
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */