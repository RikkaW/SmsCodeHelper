package com.android.mms.ui;

public abstract interface LinearAnimator$FrameHandler
{
  public abstract void onEnd();
  
  public abstract void onFrame(float paramFloat);
}

/* Location:
 * Qualified Name:     com.android.mms.ui.LinearAnimator.FrameHandler
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */