package com.android.mms.ui;

import com.android.mms.data.Conversation;

class ConversationListItem$3
  implements Runnable
{
  ConversationListItem$3(ConversationListItem paramConversationListItem) {}
  
  public void run()
  {
    ConversationListItem.access$400(this$0).markAsReadSync();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationListItem.3
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */