package com.android.mms.ui;

import android.view.View;
import android.view.View.OnClickListener;

class AttachmentView$2
  implements View.OnClickListener
{
  AttachmentView$2(AttachmentView paramAttachmentView) {}
  
  public void onClick(View paramView)
  {
    this$0.showPopup();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AttachmentView.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */