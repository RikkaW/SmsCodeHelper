package com.android.mms.ui;

class ConversationListItem$4
  implements Runnable
{
  ConversationListItem$4(ConversationListItem paramConversationListItem) {}
  
  public void run()
  {
    if (ConversationListItem.access$500(this$0))
    {
      ConversationListItem.access$600(this$0);
      ConversationListItem.access$700(this$0);
    }
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationListItem.4
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */