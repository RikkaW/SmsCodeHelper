package com.android.mms.ui;

public abstract interface ConversationListAdapter$OnContentChangedListener
{
  public abstract void onContentChanged(ConversationListAdapter paramConversationListAdapter);
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationListAdapter.OnContentChangedListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */