package com.android.mms.ui;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class ClassZeroActivity$3
  implements DialogInterface.OnClickListener
{
  ClassZeroActivity$3(ClassZeroActivity paramClassZeroActivity) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    ClassZeroActivity.access$002(this$0, true);
    ClassZeroActivity.access$200(this$0);
    paramDialogInterface.dismiss();
    ClassZeroActivity.access$300(this$0);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ClassZeroActivity.3
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */