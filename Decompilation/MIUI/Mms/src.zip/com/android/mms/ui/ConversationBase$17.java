package com.android.mms.ui;

import android.content.Context;

class ConversationBase$17
  implements Runnable
{
  ConversationBase$17(ConversationBase paramConversationBase, Context paramContext) {}
  
  public void run()
  {
    this$0.updateSlotButtonStateBySlotId(val$context, this$0.mUseSlotId);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationBase.17
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */