package com.android.mms.ui;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;

class ConversationFragment$5
  implements View.OnClickListener
{
  ConversationFragment$5(ConversationFragment paramConversationFragment) {}
  
  public void onClick(View paramView)
  {
    paramView = new Intent("com.xiaomi.action.MICLOUD_MAIN");
    this$0.startActivity(paramView);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationFragment.5
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */