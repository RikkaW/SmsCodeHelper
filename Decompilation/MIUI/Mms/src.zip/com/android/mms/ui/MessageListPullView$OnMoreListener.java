package com.android.mms.ui;

public abstract interface MessageListPullView$OnMoreListener
{
  public abstract void onMore();
}

/* Location:
 * Qualified Name:     com.android.mms.ui.MessageListPullView.OnMoreListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */