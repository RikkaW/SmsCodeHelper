package com.android.mms.ui;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.view.ActionMode;

class ConversationBase$ModeCallback$2
  implements DialogInterface.OnClickListener
{
  ConversationBase$ModeCallback$2(ConversationBase.ModeCallback paramModeCallback, ActionMode paramActionMode) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    val$mode.finish();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationBase.ModeCallback.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */