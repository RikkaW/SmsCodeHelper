package com.android.mms.ui;

import android.view.View;
import android.view.View.OnClickListener;

class AttachmentProcessor$2
  implements View.OnClickListener
{
  AttachmentProcessor$2(AttachmentProcessor paramAttachmentProcessor, int paramInt) {}
  
  public void onClick(View paramView)
  {
    this$0.onAttachmentTypeClick(val$finalIndex);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AttachmentProcessor.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */