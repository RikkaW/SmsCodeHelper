package com.android.mms.ui;

import android.view.View;
import android.view.View.OnClickListener;

class AttachmentProcessor$1
  implements View.OnClickListener
{
  AttachmentProcessor$1(AttachmentProcessor paramAttachmentProcessor, int paramInt) {}
  
  public void onClick(View paramView)
  {
    AttachmentProcessor.access$400(this$0, val$index);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AttachmentProcessor.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */