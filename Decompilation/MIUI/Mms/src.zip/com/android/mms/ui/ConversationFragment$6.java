package com.android.mms.ui;

import miui.widget.MiCloudStateView;

class ConversationFragment$6
  implements PrivateEntryView.OnPrivateColorChangeListener
{
  ConversationFragment$6(ConversationFragment paramConversationFragment) {}
  
  public void onColorChange(int paramInt)
  {
    ConversationFragment.access$1200(this$0).setBackgroundColor(paramInt);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationFragment.6
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */