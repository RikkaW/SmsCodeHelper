package com.android.mms.ui;

import com.android.mms.data.Conversation;

class ConversationBase$14
  implements Runnable
{
  ConversationBase$14(ConversationBase paramConversationBase) {}
  
  public void run()
  {
    this$0.mConversation.markAsReadSync();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationBase.14
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */