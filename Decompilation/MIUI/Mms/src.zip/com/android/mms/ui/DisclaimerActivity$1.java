package com.android.mms.ui;

import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;

class DisclaimerActivity$1
  implements DialogInterface.OnDismissListener
{
  DisclaimerActivity$1(DisclaimerActivity paramDisclaimerActivity) {}
  
  public void onDismiss(DialogInterface paramDialogInterface)
  {
    this$0.finish();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.DisclaimerActivity.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */