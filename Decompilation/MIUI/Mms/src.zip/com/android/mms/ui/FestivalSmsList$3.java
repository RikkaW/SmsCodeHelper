package com.android.mms.ui;

import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

class FestivalSmsList$3
  implements AdapterView.OnItemClickListener
{
  FestivalSmsList$3(FestivalSmsList paramFestivalSmsList) {}
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    FestivalSmsList.access$500(this$0, (ListView)paramAdapterView, paramView, paramInt, paramLong);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.FestivalSmsList.3
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */