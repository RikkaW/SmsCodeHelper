package com.android.mms.ui;

import android.view.View;
import android.view.View.OnClickListener;

class ConversationBase$7
  implements View.OnClickListener
{
  ConversationBase$7(ConversationBase paramConversationBase) {}
  
  public void onClick(View paramView)
  {
    this$0.mMsgListView.setAllowTranscriptOnResize(true);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationBase.7
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */