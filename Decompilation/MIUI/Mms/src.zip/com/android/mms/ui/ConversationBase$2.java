package com.android.mms.ui;

class ConversationBase$2
  implements Runnable
{
  ConversationBase$2(ConversationBase paramConversationBase) {}
  
  public void run()
  {
    this$0.startMsgListQuery();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationBase.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */