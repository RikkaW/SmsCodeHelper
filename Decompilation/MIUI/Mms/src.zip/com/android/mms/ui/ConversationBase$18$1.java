package com.android.mms.ui;

class ConversationBase$18$1
  implements Runnable
{
  ConversationBase$18$1(ConversationBase.18 param18) {}
  
  public void run()
  {
    this$1.this$0.applyPendingCursor();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationBase.18.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */