package com.android.mms.ui;

import android.content.Context;

final class AlertDialogHelper$2
  implements AlertDialogHelper.UrlSpan.UrlSpanOnClickListener
{
  AlertDialogHelper$2(Context paramContext) {}
  
  public void onClick()
  {
    val$context.startActivity(AlertDialogHelper.access$100());
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AlertDialogHelper.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */