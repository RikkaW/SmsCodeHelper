package com.android.mms.ui;

abstract interface SizeAwareLinearLayout$OnMeasureListener
{
  public abstract void onPostLayout();
  
  public abstract void onPreMeasure(SizeAwareLinearLayout paramSizeAwareLinearLayout, int paramInt1, int paramInt2);
}

/* Location:
 * Qualified Name:     com.android.mms.ui.SizeAwareLinearLayout.OnMeasureListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */