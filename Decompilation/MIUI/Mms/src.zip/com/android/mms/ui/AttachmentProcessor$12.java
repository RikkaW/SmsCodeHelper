package com.android.mms.ui;

class AttachmentProcessor$12
  implements Runnable
{
  AttachmentProcessor$12(AttachmentProcessor paramAttachmentProcessor) {}
  
  public void run()
  {
    AttachmentProcessor.access$1000(this$0);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AttachmentProcessor.12
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */