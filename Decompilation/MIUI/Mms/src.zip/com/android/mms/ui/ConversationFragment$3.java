package com.android.mms.ui;

import android.accounts.Account;
import android.accounts.OnAccountsUpdateListener;

class ConversationFragment$3
  implements OnAccountsUpdateListener
{
  ConversationFragment$3(ConversationFragment paramConversationFragment) {}
  
  public void onAccountsUpdated(Account[] paramArrayOfAccount)
  {
    ConversationFragment.access$1100(this$0);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationFragment.3
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */