package com.android.mms.ui;

import android.content.Context;

final class AlertDialogHelper$1
  implements AlertDialogHelper.UrlSpan.UrlSpanOnClickListener
{
  AlertDialogHelper$1(Context paramContext) {}
  
  public void onClick()
  {
    val$context.startActivity(AlertDialogHelper.access$000());
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AlertDialogHelper.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */