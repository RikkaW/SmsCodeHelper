package com.android.mms.ui;

import android.telephony.SmsMessage;

class ClassZeroActivity$MessageItem
{
  public SmsMessage mMessage;
  public long mSimId;
  
  public ClassZeroActivity$MessageItem(SmsMessage paramSmsMessage, long paramLong)
  {
    mMessage = paramSmsMessage;
    mSimId = paramLong;
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ClassZeroActivity.MessageItem
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */