package com.android.mms.ui;

class AttachmentProcessor$13
  implements Runnable
{
  AttachmentProcessor$13(AttachmentProcessor paramAttachmentProcessor) {}
  
  public void run()
  {
    AttachmentProcessor.access$100(this$0).toggleSubject();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AttachmentProcessor.13
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */