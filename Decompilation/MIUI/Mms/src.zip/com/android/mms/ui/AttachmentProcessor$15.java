package com.android.mms.ui;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class AttachmentProcessor$15
  implements DialogInterface.OnClickListener
{
  AttachmentProcessor$15(AttachmentProcessor paramAttachmentProcessor) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    paramDialogInterface.dismiss();
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.AttachmentProcessor.15
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */