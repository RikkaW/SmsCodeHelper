package com.android.mms.ui;

public abstract interface ViewInterface
{
  public abstract void reset();
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ViewInterface
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */