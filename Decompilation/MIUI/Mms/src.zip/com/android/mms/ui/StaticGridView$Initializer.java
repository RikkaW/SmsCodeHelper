package com.android.mms.ui;

public abstract interface StaticGridView$Initializer
{
  public abstract void onInitialize(StaticGridView paramStaticGridView);
}

/* Location:
 * Qualified Name:     com.android.mms.ui.StaticGridView.Initializer
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */