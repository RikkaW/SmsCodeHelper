package com.android.mms.ui;

import android.view.View;
import android.view.View.OnClickListener;

class ConfirmRateLimitActivity$2
  implements View.OnClickListener
{
  ConfirmRateLimitActivity$2(ConfirmRateLimitActivity paramConfirmRateLimitActivity) {}
  
  public void onClick(View paramView)
  {
    ConfirmRateLimitActivity.access$000(this$0, false);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConfirmRateLimitActivity.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */