package com.android.mms.ui;

import android.widget.PopupWindow.OnDismissListener;

class ConversationBase$13
  implements PopupWindow.OnDismissListener
{
  ConversationBase$13(ConversationBase paramConversationBase) {}
  
  public void onDismiss()
  {
    ConversationBase.access$1002(this$0, null);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ui.ConversationBase.13
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */