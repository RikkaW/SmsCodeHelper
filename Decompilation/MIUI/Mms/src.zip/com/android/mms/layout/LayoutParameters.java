package com.android.mms.layout;

public abstract interface LayoutParameters
{
  public abstract int getHeight();
  
  public abstract int getImageHeight();
  
  public abstract int getTextHeight();
  
  public abstract int getWidth();
}

/* Location:
 * Qualified Name:     com.android.mms.layout.LayoutParameters
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */