package com.android.mms;

public final class ResolutionException
  extends ContentRestrictionException
{
  private static final long serialVersionUID = 5509925632215500520L;
  
  public ResolutionException() {}
  
  public ResolutionException(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.ResolutionException
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */