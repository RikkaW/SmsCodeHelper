package com.android.mms.understand;

public abstract interface UnderstandLoader$RequestCallback
{
  public abstract void onRequestDone(boolean paramBoolean);
}

/* Location:
 * Qualified Name:     com.android.mms.understand.UnderstandLoader.RequestCallback
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */