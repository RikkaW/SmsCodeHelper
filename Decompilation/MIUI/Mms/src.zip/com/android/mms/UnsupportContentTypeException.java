package com.android.mms;

public final class UnsupportContentTypeException
  extends ContentRestrictionException
{
  private static final long serialVersionUID = 2684128059358484321L;
  
  public UnsupportContentTypeException() {}
  
  public UnsupportContentTypeException(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.UnsupportContentTypeException
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */