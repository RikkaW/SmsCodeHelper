package com.xiaomi.mms.data;

public abstract interface MxIdCache$MxCacheStatusListener
{
  public abstract void onMxIdAdded(String paramString1, String paramString2);
  
  public abstract void onMxIdOffline(String paramString1, String paramString2);
  
  public abstract void onMxIdOnline(String paramString1, String paramString2);
}

/* Location:
 * Qualified Name:     com.xiaomi.mms.data.MxIdCache.MxCacheStatusListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */