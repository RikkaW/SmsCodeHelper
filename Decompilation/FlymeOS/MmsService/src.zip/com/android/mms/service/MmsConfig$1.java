package com.android.mms.service;

class MmsConfig$1
  implements MmsConfigXmlProcessor.MmsConfigHandler
{
  MmsConfig$1(MmsConfig paramMmsConfig) {}
  
  public void process(String paramString1, String paramString2, String paramString3)
  {
    MmsConfig.access$000(this$0, paramString1, paramString2, paramString3);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.service.MmsConfig.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */