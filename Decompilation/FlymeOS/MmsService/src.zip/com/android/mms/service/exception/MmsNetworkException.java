package com.android.mms.service.exception;

public class MmsNetworkException
  extends Exception
{
  public MmsNetworkException() {}
  
  public MmsNetworkException(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.service.exception.MmsNetworkException
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */