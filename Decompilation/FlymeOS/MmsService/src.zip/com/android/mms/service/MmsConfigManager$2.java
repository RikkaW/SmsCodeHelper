package com.android.mms.service;

import android.telephony.SubscriptionManager.OnSubscriptionsChangedListener;

class MmsConfigManager$2
  extends SubscriptionManager.OnSubscriptionsChangedListener
{
  MmsConfigManager$2(MmsConfigManager paramMmsConfigManager) {}
  
  public void onSubscriptionsChanged()
  {
    MmsConfigManager.access$000(this$0);
  }
}

/* Location:
 * Qualified Name:     com.android.mms.service.MmsConfigManager.2
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */