package com.android.mms.service;

public abstract interface MmsConfigXmlProcessor$MmsConfigHandler
{
  public abstract void process(String paramString1, String paramString2, String paramString3);
}

/* Location:
 * Qualified Name:     com.android.mms.service.MmsConfigXmlProcessor.MmsConfigHandler
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */