class Dummy {}

/* Location:
 * Qualified Name:     Dummy
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */