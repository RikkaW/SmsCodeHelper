public enum aej$a
{
  private aej$a() {}
}

/* Location:
 * Qualified Name:     aej.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */