import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;

class alg
  implements DialogInterface.OnCancelListener
{
  alg(ald paramald) {}
  
  public void onCancel(DialogInterface paramDialogInterface) {}
}

/* Location:
 * Qualified Name:     alg
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */