import android.util.Log;

class abb
  extends aio
{
  abb(aba paramaba) {}
  
  public void a(int paramInt, String paramString)
  {
    Log.v("SipSmsManager", "onOnlineStatusChanged, status = " + paramInt + ", mCurrentSipStatu = " + aba.a(a) + ", ext = " + paramString);
    int i;
    if (aba.a(a) != paramInt)
    {
      i = 1;
      if (i != 0) {
        break label72;
      }
    }
    label72:
    do
    {
      return;
      i = 0;
      break;
      aba.a(a, paramInt);
    } while (aba.b(a) == null);
    aba.b(a).a(paramInt);
  }
}

/* Location:
 * Qualified Name:     abb
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */