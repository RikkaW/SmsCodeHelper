import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class aku
  implements DialogInterface.OnClickListener
{
  aku(aks paramaks, aks.a parama) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    a.g.a(aks.a.a.a.b);
  }
}

/* Location:
 * Qualified Name:     aku
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */