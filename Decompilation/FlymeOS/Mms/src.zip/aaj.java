import android.content.Context;

final class aaj
  implements Runnable
{
  aaj(String paramString1, Context paramContext, String paramString2) {}
  
  public void run()
  {
    new aak(this).execute(new Void[0]);
  }
}

/* Location:
 * Qualified Name:     aaj
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */