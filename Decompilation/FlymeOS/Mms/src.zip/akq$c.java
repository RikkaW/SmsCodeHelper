public final class akq$c
{
  public static final int mzuc_stat_sys_update = 2130838626;
}

/* Location:
 * Qualified Name:     akq.c
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */