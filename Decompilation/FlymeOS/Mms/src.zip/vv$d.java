public abstract interface vv$d
{
  public abstract void a(vv paramvv);
}

/* Location:
 * Qualified Name:     vv.d
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */