public final class abl$a
{
  public gm a;
  public boolean b;
  public int c;
}

/* Location:
 * Qualified Name:     abl.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */