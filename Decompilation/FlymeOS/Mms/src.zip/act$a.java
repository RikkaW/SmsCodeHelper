public class act$a
{
  public int a;
  public String b;
  public String c;
  
  public act$a() {}
  
  public act$a(int paramInt, String paramString1, String paramString2)
  {
    a = paramInt;
    b = paramString1;
    c = paramString2;
  }
}

/* Location:
 * Qualified Name:     act.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */