import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

class aas
  extends BroadcastReceiver
{
  aas(aar paramaar) {}
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if ("com.android.mms.RATE_LIMIT_CONFIRMED".equals(paramIntent.getAction())) {}
    for (;;)
    {
      try
      {
        paramContext = a;
        if (!paramIntent.getBooleanExtra("answer", false)) {
          break label50;
        }
        i = 1;
        aar.a(paramContext, i);
        notifyAll();
        return;
      }
      finally {}
      return;
      label50:
      int i = 2;
    }
  }
}

/* Location:
 * Qualified Name:     aas
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */