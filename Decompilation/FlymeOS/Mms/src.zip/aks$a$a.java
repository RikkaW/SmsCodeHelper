public abstract interface aks$a$a
{
  public abstract void a(aks.a.a.a parama);
  
  public static enum a
  {
    private a() {}
  }
}

/* Location:
 * Qualified Name:     aks.a.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */