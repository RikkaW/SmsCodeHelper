public class aiz
{
  public aix a(aiy paramaiy)
  {
    aix localaix = new aix();
    a = paramaiy.a();
    b = paramaiy.a();
    c = paramaiy.b();
    d = (c + a);
    return localaix;
  }
}

/* Location:
 * Qualified Name:     aiz
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */