class ahr$1 {}

/* Location:
 * Qualified Name:     ahr.1
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */