import com.android.mms.view.MeizuSearchListItem;

public class ada
  implements Runnable
{
  public ada(MeizuSearchListItem paramMeizuSearchListItem) {}
  
  public void run()
  {
    MeizuSearchListItem.a(a, false);
  }
}

/* Location:
 * Qualified Name:     ada
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */