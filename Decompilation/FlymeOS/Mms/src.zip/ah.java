public abstract interface ah
{
  public abstract m a(int paramInt, l[] paramArrayOfl);
  
  public abstract m a(m[] paramArrayOfm);
}

/* Location:
 * Qualified Name:     ah
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */