import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;

class alk
  implements DialogInterface.OnCancelListener
{
  alk(ali paramali) {}
  
  public void onCancel(DialogInterface paramDialogInterface)
  {
    ald.a(a.a);
  }
}

/* Location:
 * Qualified Name:     alk
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */