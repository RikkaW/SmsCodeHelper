public final class ajk
{
  public static int a = 400;
  public static int b = 300;
  public static int c = 200;
  public static int d = 10000;
  public static int e = 50000;
  public static int f = 50;
}

/* Location:
 * Qualified Name:     ajk
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */