class aju
  implements Runnable
{
  aju(ajt paramajt) {}
  
  public void run()
  {
    ajt.a(a).b();
  }
}

/* Location:
 * Qualified Name:     aju
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */