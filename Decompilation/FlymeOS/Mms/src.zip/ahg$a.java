class ahg$a
{
  private ahf a = null;
  private String b = null;
  
  public ahf a()
  {
    return a;
  }
  
  public void a(ahf paramahf)
  {
    a = paramahf;
  }
  
  public void a(String paramString)
  {
    b = paramString.replace("##", "#");
  }
  
  public String b()
  {
    return b;
  }
}

/* Location:
 * Qualified Name:     ahg.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */