import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

class aef
  extends AnimatorListenerAdapter
{
  aef(aee paramaee) {}
  
  public void onAnimationEnd(Animator paramAnimator)
  {
    aee.a(a).c();
  }
}

/* Location:
 * Qualified Name:     aef
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */