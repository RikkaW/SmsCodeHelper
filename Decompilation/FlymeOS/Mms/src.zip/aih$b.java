public final class aih$b
{
  public static final int activity_horizontal_margin = 2131558557;
  public static final int activity_vertical_margin = 2131558625;
  public static final int mw_recipient_btn_padding = 2131559381;
  public static final int mw_recipient_btn_padding_bottom = 2131559382;
  public static final int mw_recipient_btn_padding_top = 2131559383;
  public static final int mw_recipient_hint2_padding_right = 2131559384;
  public static final int mw_recipient_hint_padding_right = 2131559385;
  public static final int mw_recipient_layout_padding_bottom = 2131559386;
  public static final int mw_recipient_layout_padding_top = 2131559387;
  public static final int mw_recipient_list_item_height = 2131559388;
  public static final int mw_recipient_list_item_padding_left = 2131559389;
  public static final int mw_recipient_list_item_padding_right = 2131559390;
  public static final int mw_recipient_max_height = 2131559391;
  public static final int mw_recipient_min_height = 2131559392;
  public static final int mw_recipient_padding_left = 2131559393;
  public static final int mw_recipient_padding_right = 2131559394;
  public static final int mw_recipient_text_padding = 2131559395;
  public static final int mw_recipient_text_paddingtop = 2131559396;
  public static final int mw_recipient_text_size = 2131559397;
  public static final int mw_recipient_text_size_easymode = 2131559398;
  public static final int mw_recipient_total_padding_right = 2131559399;
}

/* Location:
 * Qualified Name:     aih.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */