import java.io.Serializable;

final class aga
  implements Serializable
{
  protected byte[] a = new byte[16];
  protected short b = 0;
  protected byte[] c = new byte[32];
}

/* Location:
 * Qualified Name:     aga
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */