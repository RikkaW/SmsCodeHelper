import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import com.meizu.update.UpdateInfo;

class alr
  implements DialogInterface.OnCancelListener
{
  alr(alo paramalo) {}
  
  public void onCancel(DialogInterface paramDialogInterface)
  {
    alo.a(a, true);
    and.a(a.a).a(and.a.g, a.b.mVersionName);
    alo.a(a);
  }
}

/* Location:
 * Qualified Name:     alr
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */