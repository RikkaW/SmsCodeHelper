import android.net.Uri;

public abstract interface aco$a
{
  public abstract void a();
  
  public abstract void a(Uri paramUri);
  
  public abstract void b();
  
  public abstract void b(Uri paramUri);
}

/* Location:
 * Qualified Name:     aco.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */