public abstract interface afa
{
  public abstract void a();
  
  public abstract void a(aey paramaey);
  
  public abstract void b();
}

/* Location:
 * Qualified Name:     afa
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */