import android.os.Bundle;

class ale
  extends amt.a
{
  ale(ald paramald) {}
  
  public void a(int paramInt, Bundle paramBundle)
  {
    ald.a(a, new alf(this, paramInt));
  }
  
  public void b(int paramInt, Bundle paramBundle) {}
}

/* Location:
 * Qualified Name:     ale
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */