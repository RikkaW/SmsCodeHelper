import com.meizu.statsapp.UsageStatusLog;
import java.util.Map;

class ajo
  implements Runnable
{
  ajo(ajn paramajn) {}
  
  public void run()
  {
    ajn.a(a).clear();
    UsageStatusLog.d("UsageStatsManagerServer", "cleared packageSessionMap ");
  }
}

/* Location:
 * Qualified Name:     ajo
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */