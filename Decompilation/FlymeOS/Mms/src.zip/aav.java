import java.util.HashMap;

public class aav
{
  private static final HashMap<Object, Long> a = new HashMap();
  
  public static void a(Object paramObject)
  {
    try
    {
      a.remove(paramObject);
      return;
    }
    finally
    {
      paramObject = finally;
      throw ((Throwable)paramObject);
    }
  }
  
  public static void a(Object paramObject, long paramLong)
  {
    try
    {
      a.put(paramObject, Long.valueOf(paramLong));
      return;
    }
    finally
    {
      paramObject = finally;
      throw ((Throwable)paramObject);
    }
  }
}

/* Location:
 * Qualified Name:     aav
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */