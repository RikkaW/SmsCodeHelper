import com.meizu.update.UpdateInfo;

class akm
  implements Runnable
{
  akm(akl paramakl, boolean paramBoolean) {}
  
  public void run()
  {
    UpdateInfo localUpdateInfo = akl.a(b).a(a);
    if (localUpdateInfo != null)
    {
      akl.a(b).a(localUpdateInfo);
      return;
    }
    akl.a(b).a();
  }
}

/* Location:
 * Qualified Name:     akm
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */