class alc
  implements aks.a.a
{
  alc(alb paramalb) {}
  
  public void a(aks.a.a.a parama)
  {
    switch (alb.1.a[parama.ordinal()])
    {
    default: 
      return;
    case 1: 
      alb.a(a);
      return;
    }
    alb.b(a);
  }
}

/* Location:
 * Qualified Name:     alc
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */