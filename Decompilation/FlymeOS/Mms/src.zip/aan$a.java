import com.meizu.android.mms.pdu.MzGenericPdu;

public class aan$a
{
  public final MzGenericPdu a;
  public final lr b;
  
  public aan$a(MzGenericPdu paramMzGenericPdu, lr paramlr)
  {
    a = paramMzGenericPdu;
    b = paramlr;
  }
}

/* Location:
 * Qualified Name:     aan.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */