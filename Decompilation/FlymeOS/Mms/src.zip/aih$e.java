public final class aih$e
{
  public static final int mw_recipient_edit_layout = 2130968768;
  public static final int mw_recipient_edit_layout_easymode = 2130968769;
  public static final int mw_recipient_itemview = 2130968770;
  public static final int mw_recipient_itemview_calendar = 2130968771;
  public static final int mw_recipient_itemview_easymode = 2130968772;
  public static final int mw_recipient_itemview_mns = 2130968773;
  public static final int mw_recipient_list_item = 2130968774;
  public static final int mw_recipient_list_loading = 2130968775;
}

/* Location:
 * Qualified Name:     aih.e
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */