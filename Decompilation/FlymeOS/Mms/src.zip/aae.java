import android.os.Handler;
import android.os.Message;

class aae
  extends Handler
{
  aae(aad paramaad) {}
  
  public void handleMessage(Message paramMessage)
  {
    wd.a(aad.a(a, what), aad.c(a), 0, 1, true, 0, aaa.b());
  }
}

/* Location:
 * Qualified Name:     aae
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */