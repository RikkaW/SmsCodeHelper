public class al
  implements ah
{
  public static final ai a = ai.u;
  
  public m a(int paramInt, l[] paramArrayOfl)
  {
    throw new UnsupportedOperationException("操作符\"" + a.a() + "不支持该方法");
  }
  
  public m a(m[] paramArrayOfm)
  {
    throw new UnsupportedOperationException("操作符\"" + a.a() + "不支持该方法");
  }
}

/* Location:
 * Qualified Name:     al
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */