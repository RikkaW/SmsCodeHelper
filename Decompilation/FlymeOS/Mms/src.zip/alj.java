import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class alj
  implements DialogInterface.OnClickListener
{
  alj(ali paramali) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    ald.a(a.a);
  }
}

/* Location:
 * Qualified Name:     alj
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */