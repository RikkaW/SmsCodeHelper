import android.net.Uri;

public abstract interface vv$b
{
  public abstract void a(vv paramvv, Uri paramUri, long paramLong1, long paramLong2);
}

/* Location:
 * Qualified Name:     vv.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */