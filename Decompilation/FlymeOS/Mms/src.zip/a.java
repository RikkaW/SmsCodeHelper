class a
{
  public static void a(boolean paramBoolean, String paramString)
  {
    if (!paramBoolean) {
      throw new AssertionError(paramString);
    }
  }
}

/* Location:
 * Qualified Name:     a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */