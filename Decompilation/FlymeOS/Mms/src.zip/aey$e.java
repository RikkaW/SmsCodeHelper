public abstract interface aey$e
{
  public abstract aey.g a();
}

/* Location:
 * Qualified Name:     aey.e
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */