import android.net.Uri;

public abstract interface ach$a
{
  public abstract void a(Uri paramUri);
  
  public abstract void b(Uri paramUri);
  
  public abstract void c(Uri paramUri);
}

/* Location:
 * Qualified Name:     ach.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */