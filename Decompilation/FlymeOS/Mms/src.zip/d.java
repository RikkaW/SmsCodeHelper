public abstract interface d<T>
{
  public abstract T a(ai paramai, T paramT1, T paramT2);
  
  public abstract boolean b(ai paramai, T paramT1, T paramT2);
}

/* Location:
 * Qualified Name:     d
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */