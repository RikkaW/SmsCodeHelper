import com.ted.android.core.SmsEntityLoader.SmsEntityLoaderCallback;
import com.ted.android.data.SmsEntity;

class abv
  implements SmsEntityLoader.SmsEntityLoaderCallback
{
  abv(abu paramabu, Runnable paramRunnable) {}
  
  public void onSmsEntityLoaded(Long paramLong, SmsEntity paramSmsEntity)
  {
    if ((ab).ab * 1000L + ab).e == paramLong.longValue()) && (paramSmsEntity != null) && (abu.b(b)))
    {
      abu.a(b, paramSmsEntity);
      if (a != null) {
        a.run();
      }
    }
  }
}

/* Location:
 * Qualified Name:     abv
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */