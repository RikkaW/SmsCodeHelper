import com.meizu.update.UpdateInfo;

class alh
  implements aks.a.a
{
  alh(ald paramald) {}
  
  public void a(aks.a.a.a parama)
  {
    switch (ald.1.a[parama.ordinal()])
    {
    default: 
      return;
    case 1: 
      and.a(a.a).a(and.a.j, a.b.mVersionName);
      a.c();
      return;
    case 2: 
      and.a(a.a).a(and.a.k, a.b.mVersionName);
      akk.c(a.a);
      ald.a(a);
      return;
    }
    and.a(a.a).a(and.a.k, a.b.mVersionName);
    ald.a(a);
  }
}

/* Location:
 * Qualified Name:     alh
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */