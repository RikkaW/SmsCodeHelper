class afl$a
  extends Exception
{
  public afl$a(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     afl.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */