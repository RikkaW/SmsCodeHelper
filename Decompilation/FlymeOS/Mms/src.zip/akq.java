public final class akq
{
  public static final class a
  {
    public static final int mzuc_dialog_msg_text_color = 2131820821;
    public static final int mzuc_dialog_sub_title_text_color = 2131820822;
    public static final int mzuc_progress_bar_color = 2131820823;
  }
  
  public static final class b
  {
    public static final int activity_horizontal_margin = 2131558557;
    public static final int activity_vertical_margin = 2131558625;
    public static final int mzuc_dialog_btn_text_size_small = 2131559747;
    public static final int mzuc_dialog_msg_line_spacing = 2131559748;
    public static final int mzuc_dialog_msg_text_size = 2131559749;
    public static final int mzuc_dialog_sub_title_text_size = 2131559750;
    public static final int mzuc_dialog_title_line_spacing = 2131559751;
  }
  
  public static final class c
  {
    public static final int mzuc_stat_sys_update = 2130838626;
  }
  
  public static final class d
  {
    public static final int action_settings = 2131493860;
    public static final int app_name = 2131493863;
    public static final int hello_world = 2131493926;
    public static final int mzuc_cancel = 2131493175;
    public static final int mzuc_cancel_download = 2131493176;
    public static final int mzuc_cancel_install = 2131493177;
    public static final int mzuc_delete = 2131493178;
    public static final int mzuc_download_fail = 2131493179;
    public static final int mzuc_download_finish_install = 2131493180;
    public static final int mzuc_download_finish_s = 2131493181;
    public static final int mzuc_download_progress_desc_s = 2131493182;
    public static final int mzuc_downloading = 2131493183;
    public static final int mzuc_file_size_s = 2131493184;
    public static final int mzuc_found_update_s = 2131493185;
    public static final int mzuc_install_cancel_tip = 2131493186;
    public static final int mzuc_install_fail = 2131493187;
    public static final int mzuc_install_immediately = 2131493188;
    public static final int mzuc_install_later = 2131493189;
    public static final int mzuc_installing = 2131493190;
    public static final int mzuc_notification_message_s = 2131493191;
    public static final int mzuc_ok = 2131493192;
    public static final int mzuc_retry = 2131493193;
    public static final int mzuc_skip_version = 2131493194;
    public static final int mzuc_skip_warn_tip = 2131493195;
    public static final int mzuc_update_finish = 2131493196;
    public static final int mzuc_update_immediately = 2131493197;
    public static final int mzuc_update_msg_title_s = 2131493198;
    public static final int mzuc_update_title_s = 2131493199;
    public static final int mzuc_wait_tip = 2131493200;
    public static final int mzuc_warn_later = 2131493201;
  }
}

/* Location:
 * Qualified Name:     akq
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */