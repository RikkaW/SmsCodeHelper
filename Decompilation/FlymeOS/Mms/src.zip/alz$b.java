import android.util.Log;

class alz$b
{
  private final String a;
  private final int b;
  
  private void a(String paramString)
  {
    Log.println(b, a, paramString);
  }
  
  private boolean a()
  {
    return Log.isLoggable(a, b);
  }
}

/* Location:
 * Qualified Name:     alz.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */