import com.android.mms.view.MessageListItemSms;

public class adu
  implements Runnable
{
  public adu(MessageListItemSms paramMessageListItemSms) {}
  
  public void run()
  {
    a.z();
  }
}

/* Location:
 * Qualified Name:     adu
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */