import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import com.android.mms.view.MessagePopupGroupView.a;

class aei
  implements ValueAnimator.AnimatorUpdateListener
{
  aei(aee paramaee, boolean paramBoolean, MessagePopupGroupView.a parama) {}
  
  public void onAnimationUpdate(ValueAnimator paramValueAnimator)
  {
    if (a) {
      b.c(aee.a(c, b));
    }
  }
}

/* Location:
 * Qualified Name:     aei
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */