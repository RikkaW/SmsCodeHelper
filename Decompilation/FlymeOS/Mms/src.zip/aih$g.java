public final class aih$g
{
  public static final int[] RecipientEdit = { 2130772272, 2130772273, 2130772274, 2130772275 };
  public static final int RecipientEdit_isEasyMode = 3;
  public static final int RecipientEdit_mzHint = 1;
  public static final int RecipientEdit_mzInputType = 0;
  public static final int RecipientEdit_mzMaxHeight = 2;
}

/* Location:
 * Qualified Name:     aih.g
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */