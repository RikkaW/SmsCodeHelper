import android.net.Uri;

class abn
  implements zz
{
  private boolean c;
  
  abn(abm paramabm, zy paramzy) {}
  
  public void a(Uri paramUri)
  {
    b.a(a);
    b.a(paramUri);
  }
  
  public void a(boolean paramBoolean)
  {
    c = paramBoolean;
  }
  
  public boolean a()
  {
    return c;
  }
}

/* Location:
 * Qualified Name:     abn
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */