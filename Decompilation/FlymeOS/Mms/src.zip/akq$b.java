public final class akq$b
{
  public static final int activity_horizontal_margin = 2131558557;
  public static final int activity_vertical_margin = 2131558625;
  public static final int mzuc_dialog_btn_text_size_small = 2131559747;
  public static final int mzuc_dialog_msg_line_spacing = 2131559748;
  public static final int mzuc_dialog_msg_text_size = 2131559749;
  public static final int mzuc_dialog_sub_title_text_size = 2131559750;
  public static final int mzuc_dialog_title_line_spacing = 2131559751;
}

/* Location:
 * Qualified Name:     akq.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */