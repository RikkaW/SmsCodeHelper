import android.media.MediaRecorder;
import android.media.MediaRecorder.OnErrorListener;

class acp
  implements MediaRecorder.OnErrorListener
{
  acp(aco paramaco) {}
  
  public void onError(MediaRecorder paramMediaRecorder, int paramInt1, int paramInt2)
  {
    a.a(2131493555);
  }
}

/* Location:
 * Qualified Name:     acp
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */