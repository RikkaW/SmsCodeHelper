public class aai$b {}

/* Location:
 * Qualified Name:     aai.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */