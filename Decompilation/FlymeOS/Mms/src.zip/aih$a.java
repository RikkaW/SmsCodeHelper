public final class aih$a
{
  public static final int mw_recipient_text_addrecipient_easymode = 2131820746;
  public static final int mw_recipient_text_black = 2131820747;
  public static final int mw_recipient_text_blue = 2131820748;
  public static final int mw_recipient_text_gray = 2131820749;
  public static final int mw_recipient_text_green = 2131820750;
  public static final int mw_recipient_text_invalidate = 2131820751;
  public static final int mw_recipient_text_invalidate_calendar = 2131820752;
  public static final int mw_recipient_text_red = 2131820753;
  public static final int mw_recipient_text_white = 2131820754;
}

/* Location:
 * Qualified Name:     aih.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */