import android.net.Uri;

public abstract interface zz
{
  public abstract void a(Uri paramUri);
  
  public abstract void a(boolean paramBoolean);
  
  public abstract boolean a();
}

/* Location:
 * Qualified Name:     zz
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */