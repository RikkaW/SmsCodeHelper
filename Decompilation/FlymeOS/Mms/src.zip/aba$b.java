public abstract interface aba$b
{
  public abstract void a(int paramInt);
}

/* Location:
 * Qualified Name:     aba.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */