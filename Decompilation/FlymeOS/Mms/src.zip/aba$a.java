public abstract class aba$a
  extends aip
{}

/* Location:
 * Qualified Name:     aba.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */