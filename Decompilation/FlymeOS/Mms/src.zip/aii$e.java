public class aii$e
  extends aif.a
{
  public aii$e(aii paramaii)
  {
    super(false, false);
  }
}

/* Location:
 * Qualified Name:     aii.e
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */