import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.util.Log;

class acm
  implements MediaPlayer.OnCompletionListener
{
  acm(ach paramach) {}
  
  public void onCompletion(MediaPlayer paramMediaPlayer)
  {
    Log.d("VoicePlayer", "setTreamType():stop()~~~~");
    ach.c(a);
  }
}

/* Location:
 * Qualified Name:     acm
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */