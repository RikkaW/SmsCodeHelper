public class alx
  extends Exception
{
  private static final long serialVersionUID = 1L;
  private int a;
  
  public alx(int paramInt, String paramString)
  {
    super(paramString);
    a = paramInt;
  }
  
  public int a()
  {
    return a;
  }
}

/* Location:
 * Qualified Name:     alx
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */