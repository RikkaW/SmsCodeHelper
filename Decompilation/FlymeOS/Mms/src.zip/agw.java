import java.util.TimerTask;

class agw
  extends TimerTask
{
  agw(agu paramagu, int paramInt) {}
  
  public void run()
  {
    try
    {
      if (agu.j(b))
      {
        agu.c(b, a);
        if (!b.e()) {
          agu.k(b);
        }
      }
      else
      {
        agu.k(b);
        return;
      }
    }
    catch (Throwable localThrowable)
    {
      localThrowable.printStackTrace();
    }
  }
}

/* Location:
 * Qualified Name:     agw
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */