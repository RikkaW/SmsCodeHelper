public abstract interface aaq$a
{
  public abstract void a();
  
  public abstract void b();
}

/* Location:
 * Qualified Name:     aaq.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */