import com.android.mms.view.MessageListItem;

public class add
  implements Runnable
{
  public add(MessageListItem paramMessageListItem, long paramLong1, long paramLong2) {}
  
  public void run()
  {
    MessageListItem.a(c, a, b, false);
  }
}

/* Location:
 * Qualified Name:     add
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */