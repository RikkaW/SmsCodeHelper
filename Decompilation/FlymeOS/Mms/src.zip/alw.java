import android.util.Pair;
import java.util.List;

public abstract interface alw
{
  public abstract void a();
  
  public abstract void a(amm paramamm);
  
  public abstract void a(String paramString);
  
  public abstract void a(List<Pair<String, String>> paramList);
  
  public abstract boolean a(boolean paramBoolean);
}

/* Location:
 * Qualified Name:     alw
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */