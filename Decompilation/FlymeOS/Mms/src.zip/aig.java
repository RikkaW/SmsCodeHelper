public class aig
{
  public String a;
  public String b;
  public long c = 0L;
  
  public void a()
  {
    a = "";
    b = "";
    c = 0L;
  }
  
  public void a(String paramString1, String paramString2, Long paramLong)
  {
    a = paramString1;
    b = paramString2;
    c = paramLong.longValue();
  }
}

/* Location:
 * Qualified Name:     aig
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */