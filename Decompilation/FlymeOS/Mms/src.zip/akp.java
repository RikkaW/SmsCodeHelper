import android.app.Activity;
import android.content.Context;
import com.meizu.update.UpdateInfo;

public class akp
{
  public static void a(Activity paramActivity, UpdateInfo paramUpdateInfo)
  {
    ake.a(paramActivity, null, paramUpdateInfo);
  }
  
  public static void a(Context paramContext, akn paramakn)
  {
    ake.a(paramContext, paramakn, -1L, false);
  }
  
  public static final boolean a(Context paramContext, String paramString)
  {
    return ake.a(paramContext, paramString);
  }
}

/* Location:
 * Qualified Name:     akp
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */