public class alt
  extends Exception
{
  private static final long serialVersionUID = 1L;
}

/* Location:
 * Qualified Name:     alt
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */