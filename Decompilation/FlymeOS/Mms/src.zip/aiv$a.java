import android.app.PendingIntent;
import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public abstract class aiv$a
  extends Binder
  implements aiv
{
  public static aiv a(IBinder paramIBinder)
  {
    if (paramIBinder == null) {
      return null;
    }
    IInterface localIInterface = paramIBinder.queryLocalInterface("com.meizu.interfaces.IMzSnsService");
    if ((localIInterface != null) && ((localIInterface instanceof aiv))) {
      return (aiv)localIInterface;
    }
    return new aiv.a.a(paramIBinder);
  }
  
  public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
  {
    String str1;
    String str2;
    Object localObject2;
    String str3;
    Object localObject1;
    String str4;
    String str5;
    switch (paramInt1)
    {
    default: 
      return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
    case 1598968902: 
      paramParcel2.writeString("com.meizu.interfaces.IMzSnsService");
      return true;
    case 1: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.readString();
      str3 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (localObject1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; localObject1 = null)
      {
        a(str1, str2, (String)localObject2, str3, (PendingIntent)localObject1, paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      }
    case 2: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (localObject1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; localObject1 = null)
      {
        a(str1, str2, (String)localObject2, (PendingIntent)localObject1, paramParcel1.readString());
        paramParcel2.writeNoException();
        return true;
      }
    case 3: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        a((String)localObject1, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 4: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.createByteArray();
      str3 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (boolean bool = true;; bool = false)
      {
        paramParcel1 = a((String)localObject1, str1, str2, (byte[])localObject2, str3, bool, paramParcel1.readString());
        paramParcel2.writeNoException();
        paramParcel2.writeString(paramParcel1);
        return true;
      }
    case 5: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      paramParcel1 = a(paramParcel1.readString(), paramParcel1.createByteArray(), paramParcel1.readString(), paramParcel1.readString(), paramParcel1.readLong());
      paramParcel2.writeNoException();
      paramParcel2.writeByteArray(paramParcel1);
      return true;
    case 6: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.readString();
      str3 = paramParcel1.readString();
      str4 = paramParcel1.readString();
      str5 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        a((String)localObject1, str1, str2, (String)localObject2, str3, str4, str5, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 7: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        a((String)localObject1, str1, str2, (String)localObject2, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 8: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.readString();
      str3 = paramParcel1.readString();
      str4 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        a((String)localObject1, str1, str2, (String)localObject2, str3, str4, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 9: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        b((String)localObject1, str1, str2, (String)localObject2, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 10: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.readString();
      str3 = paramParcel1.readString();
      str4 = paramParcel1.readString();
      str5 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        b((String)localObject1, str1, str2, (String)localObject2, str3, str4, str5, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 11: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      localObject2 = paramParcel1.readString();
      str3 = paramParcel1.readString();
      str4 = paramParcel1.readString();
      str5 = paramParcel1.readString();
      String str6 = paramParcel1.readString();
      String str7 = paramParcel1.readString();
      String str8 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        a((String)localObject1, str1, str2, (String)localObject2, str3, str4, str5, str6, str7, str8, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 12: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        a((String)localObject1, str1, str2, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 13: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      localObject1 = paramParcel1.readString();
      str1 = paramParcel1.readString();
      str2 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (PendingIntent)PendingIntent.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        b((String)localObject1, str1, str2, paramParcel1);
        paramParcel2.writeNoException();
        return true;
      }
    case 14: 
      paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
      paramParcel1 = a(paramParcel1.readString(), paramParcel1.readString(), paramParcel1.readString(), paramParcel1.readLong());
      paramParcel2.writeNoException();
      paramParcel2.writeStringArray(paramParcel1);
      return true;
    }
    paramParcel1.enforceInterface("com.meizu.interfaces.IMzSnsService");
    a(paramParcel1.readString(), paramParcel1.readString());
    paramParcel2.writeNoException();
    return true;
  }
  
  static class a
    implements aiv
  {
    private IBinder a;
    
    a(IBinder paramIBinder)
    {
      a = paramIBinder;
    }
    
    public String a(String paramString1, String paramString2, String paramString3, byte[] paramArrayOfByte, String paramString4, boolean paramBoolean, String paramString5)
    {
      int i = 0;
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.meizu.interfaces.IMzSnsService");
        localParcel1.writeString(paramString1);
        localParcel1.writeString(paramString2);
        localParcel1.writeString(paramString3);
        localParcel1.writeByteArray(paramArrayOfByte);
        localParcel1.writeString(paramString4);
        if (paramBoolean) {
          i = 1;
        }
        localParcel1.writeInt(i);
        localParcel1.writeString(paramString5);
        a.transact(4, localParcel1, localParcel2, 0);
        localParcel2.readException();
        paramString1 = localParcel2.readString();
        return paramString1;
      }
      finally
      {
        localParcel2.recycle();
        localParcel1.recycle();
      }
    }
    
    /* Error */
    public void a(String paramString, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore_3
      //   4: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   7: astore 4
      //   9: aload_3
      //   10: ldc 27
      //   12: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   15: aload_3
      //   16: aload_1
      //   17: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   20: aload_2
      //   21: ifnull +44 -> 65
      //   24: aload_3
      //   25: iconst_1
      //   26: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   29: aload_2
      //   30: aload_3
      //   31: iconst_0
      //   32: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   35: aload_0
      //   36: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   39: iconst_3
      //   40: aload_3
      //   41: aload 4
      //   43: iconst_0
      //   44: invokeinterface 48 5 0
      //   49: pop
      //   50: aload 4
      //   52: invokevirtual 51	android/os/Parcel:readException	()V
      //   55: aload 4
      //   57: invokevirtual 58	android/os/Parcel:recycle	()V
      //   60: aload_3
      //   61: invokevirtual 58	android/os/Parcel:recycle	()V
      //   64: return
      //   65: aload_3
      //   66: iconst_0
      //   67: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   70: goto -35 -> 35
      //   73: astore_1
      //   74: aload 4
      //   76: invokevirtual 58	android/os/Parcel:recycle	()V
      //   79: aload_3
      //   80: invokevirtual 58	android/os/Parcel:recycle	()V
      //   83: aload_1
      //   84: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	85	0	this	a
      //   0	85	1	paramString	String
      //   0	85	2	paramPendingIntent	PendingIntent
      //   3	77	3	localParcel1	Parcel
      //   7	68	4	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   9	20	73	finally
      //   24	35	73	finally
      //   35	55	73	finally
      //   65	70	73	finally
    }
    
    public void a(String paramString1, String paramString2)
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.meizu.interfaces.IMzSnsService");
        localParcel1.writeString(paramString1);
        localParcel1.writeString(paramString2);
        a.transact(15, localParcel1, localParcel2, 0);
        localParcel2.readException();
        return;
      }
      finally
      {
        localParcel2.recycle();
        localParcel1.recycle();
      }
    }
    
    /* Error */
    public void a(String paramString1, String paramString2, String paramString3, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 5
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 6
      //   10: aload 5
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 5
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 5
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 5
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 4
      //   37: ifnull +50 -> 87
      //   40: aload 5
      //   42: iconst_1
      //   43: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   46: aload 4
      //   48: aload 5
      //   50: iconst_0
      //   51: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   54: aload_0
      //   55: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   58: bipush 12
      //   60: aload 5
      //   62: aload 6
      //   64: iconst_0
      //   65: invokeinterface 48 5 0
      //   70: pop
      //   71: aload 6
      //   73: invokevirtual 51	android/os/Parcel:readException	()V
      //   76: aload 6
      //   78: invokevirtual 58	android/os/Parcel:recycle	()V
      //   81: aload 5
      //   83: invokevirtual 58	android/os/Parcel:recycle	()V
      //   86: return
      //   87: aload 5
      //   89: iconst_0
      //   90: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   93: goto -39 -> 54
      //   96: astore_1
      //   97: aload 6
      //   99: invokevirtual 58	android/os/Parcel:recycle	()V
      //   102: aload 5
      //   104: invokevirtual 58	android/os/Parcel:recycle	()V
      //   107: aload_1
      //   108: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	109	0	this	a
      //   0	109	1	paramString1	String
      //   0	109	2	paramString2	String
      //   0	109	3	paramString3	String
      //   0	109	4	paramPendingIntent	PendingIntent
      //   3	100	5	localParcel1	Parcel
      //   8	90	6	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	35	96	finally
      //   40	54	96	finally
      //   54	76	96	finally
      //   87	93	96	finally
    }
    
    /* Error */
    public void a(String paramString1, String paramString2, String paramString3, PendingIntent paramPendingIntent, String paramString4)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 6
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 7
      //   10: aload 6
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 6
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 6
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 6
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 4
      //   37: ifnull +56 -> 93
      //   40: aload 6
      //   42: iconst_1
      //   43: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   46: aload 4
      //   48: aload 6
      //   50: iconst_0
      //   51: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   54: aload 6
      //   56: aload 5
      //   58: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   61: aload_0
      //   62: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   65: iconst_2
      //   66: aload 6
      //   68: aload 7
      //   70: iconst_0
      //   71: invokeinterface 48 5 0
      //   76: pop
      //   77: aload 7
      //   79: invokevirtual 51	android/os/Parcel:readException	()V
      //   82: aload 7
      //   84: invokevirtual 58	android/os/Parcel:recycle	()V
      //   87: aload 6
      //   89: invokevirtual 58	android/os/Parcel:recycle	()V
      //   92: return
      //   93: aload 6
      //   95: iconst_0
      //   96: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   99: goto -45 -> 54
      //   102: astore_1
      //   103: aload 7
      //   105: invokevirtual 58	android/os/Parcel:recycle	()V
      //   108: aload 6
      //   110: invokevirtual 58	android/os/Parcel:recycle	()V
      //   113: aload_1
      //   114: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	115	0	this	a
      //   0	115	1	paramString1	String
      //   0	115	2	paramString2	String
      //   0	115	3	paramString3	String
      //   0	115	4	paramPendingIntent	PendingIntent
      //   0	115	5	paramString4	String
      //   3	106	6	localParcel1	Parcel
      //   8	96	7	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	35	102	finally
      //   40	54	102	finally
      //   54	82	102	finally
      //   93	99	102	finally
    }
    
    /* Error */
    public void a(String paramString1, String paramString2, String paramString3, String paramString4, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 6
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 7
      //   10: aload 6
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 6
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 6
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 6
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 6
      //   37: aload 4
      //   39: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   42: aload 5
      //   44: ifnull +50 -> 94
      //   47: aload 6
      //   49: iconst_1
      //   50: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   53: aload 5
      //   55: aload 6
      //   57: iconst_0
      //   58: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   61: aload_0
      //   62: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   65: bipush 7
      //   67: aload 6
      //   69: aload 7
      //   71: iconst_0
      //   72: invokeinterface 48 5 0
      //   77: pop
      //   78: aload 7
      //   80: invokevirtual 51	android/os/Parcel:readException	()V
      //   83: aload 7
      //   85: invokevirtual 58	android/os/Parcel:recycle	()V
      //   88: aload 6
      //   90: invokevirtual 58	android/os/Parcel:recycle	()V
      //   93: return
      //   94: aload 6
      //   96: iconst_0
      //   97: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   100: goto -39 -> 61
      //   103: astore_1
      //   104: aload 7
      //   106: invokevirtual 58	android/os/Parcel:recycle	()V
      //   109: aload 6
      //   111: invokevirtual 58	android/os/Parcel:recycle	()V
      //   114: aload_1
      //   115: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	116	0	this	a
      //   0	116	1	paramString1	String
      //   0	116	2	paramString2	String
      //   0	116	3	paramString3	String
      //   0	116	4	paramString4	String
      //   0	116	5	paramPendingIntent	PendingIntent
      //   3	107	6	localParcel1	Parcel
      //   8	97	7	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	42	103	finally
      //   47	61	103	finally
      //   61	83	103	finally
      //   94	100	103	finally
    }
    
    /* Error */
    public void a(String paramString1, String paramString2, String paramString3, String paramString4, PendingIntent paramPendingIntent, String paramString5)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 7
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 8
      //   10: aload 7
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 7
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 7
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 7
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 7
      //   37: aload 4
      //   39: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   42: aload 5
      //   44: ifnull +56 -> 100
      //   47: aload 7
      //   49: iconst_1
      //   50: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   53: aload 5
      //   55: aload 7
      //   57: iconst_0
      //   58: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   61: aload 7
      //   63: aload 6
      //   65: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   68: aload_0
      //   69: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   72: iconst_1
      //   73: aload 7
      //   75: aload 8
      //   77: iconst_0
      //   78: invokeinterface 48 5 0
      //   83: pop
      //   84: aload 8
      //   86: invokevirtual 51	android/os/Parcel:readException	()V
      //   89: aload 8
      //   91: invokevirtual 58	android/os/Parcel:recycle	()V
      //   94: aload 7
      //   96: invokevirtual 58	android/os/Parcel:recycle	()V
      //   99: return
      //   100: aload 7
      //   102: iconst_0
      //   103: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   106: goto -45 -> 61
      //   109: astore_1
      //   110: aload 8
      //   112: invokevirtual 58	android/os/Parcel:recycle	()V
      //   115: aload 7
      //   117: invokevirtual 58	android/os/Parcel:recycle	()V
      //   120: aload_1
      //   121: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	122	0	this	a
      //   0	122	1	paramString1	String
      //   0	122	2	paramString2	String
      //   0	122	3	paramString3	String
      //   0	122	4	paramString4	String
      //   0	122	5	paramPendingIntent	PendingIntent
      //   0	122	6	paramString5	String
      //   3	113	7	localParcel1	Parcel
      //   8	103	8	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	42	109	finally
      //   47	61	109	finally
      //   61	89	109	finally
      //   100	106	109	finally
    }
    
    /* Error */
    public void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 8
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 9
      //   10: aload 8
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 8
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 8
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 8
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 8
      //   37: aload 4
      //   39: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   42: aload 8
      //   44: aload 5
      //   46: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   49: aload 8
      //   51: aload 6
      //   53: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   56: aload 7
      //   58: ifnull +50 -> 108
      //   61: aload 8
      //   63: iconst_1
      //   64: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   67: aload 7
      //   69: aload 8
      //   71: iconst_0
      //   72: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   75: aload_0
      //   76: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   79: bipush 8
      //   81: aload 8
      //   83: aload 9
      //   85: iconst_0
      //   86: invokeinterface 48 5 0
      //   91: pop
      //   92: aload 9
      //   94: invokevirtual 51	android/os/Parcel:readException	()V
      //   97: aload 9
      //   99: invokevirtual 58	android/os/Parcel:recycle	()V
      //   102: aload 8
      //   104: invokevirtual 58	android/os/Parcel:recycle	()V
      //   107: return
      //   108: aload 8
      //   110: iconst_0
      //   111: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   114: goto -39 -> 75
      //   117: astore_1
      //   118: aload 9
      //   120: invokevirtual 58	android/os/Parcel:recycle	()V
      //   123: aload 8
      //   125: invokevirtual 58	android/os/Parcel:recycle	()V
      //   128: aload_1
      //   129: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	130	0	this	a
      //   0	130	1	paramString1	String
      //   0	130	2	paramString2	String
      //   0	130	3	paramString3	String
      //   0	130	4	paramString4	String
      //   0	130	5	paramString5	String
      //   0	130	6	paramString6	String
      //   0	130	7	paramPendingIntent	PendingIntent
      //   3	121	8	localParcel1	Parcel
      //   8	111	9	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	56	117	finally
      //   61	75	117	finally
      //   75	97	117	finally
      //   108	114	117	finally
    }
    
    /* Error */
    public void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 9
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 10
      //   10: aload 9
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 9
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 9
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 9
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 9
      //   37: aload 4
      //   39: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   42: aload 9
      //   44: aload 5
      //   46: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   49: aload 9
      //   51: aload 6
      //   53: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   56: aload 9
      //   58: aload 7
      //   60: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   63: aload 8
      //   65: ifnull +50 -> 115
      //   68: aload 9
      //   70: iconst_1
      //   71: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   74: aload 8
      //   76: aload 9
      //   78: iconst_0
      //   79: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   82: aload_0
      //   83: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   86: bipush 6
      //   88: aload 9
      //   90: aload 10
      //   92: iconst_0
      //   93: invokeinterface 48 5 0
      //   98: pop
      //   99: aload 10
      //   101: invokevirtual 51	android/os/Parcel:readException	()V
      //   104: aload 10
      //   106: invokevirtual 58	android/os/Parcel:recycle	()V
      //   109: aload 9
      //   111: invokevirtual 58	android/os/Parcel:recycle	()V
      //   114: return
      //   115: aload 9
      //   117: iconst_0
      //   118: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   121: goto -39 -> 82
      //   124: astore_1
      //   125: aload 10
      //   127: invokevirtual 58	android/os/Parcel:recycle	()V
      //   130: aload 9
      //   132: invokevirtual 58	android/os/Parcel:recycle	()V
      //   135: aload_1
      //   136: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	137	0	this	a
      //   0	137	1	paramString1	String
      //   0	137	2	paramString2	String
      //   0	137	3	paramString3	String
      //   0	137	4	paramString4	String
      //   0	137	5	paramString5	String
      //   0	137	6	paramString6	String
      //   0	137	7	paramString7	String
      //   0	137	8	paramPendingIntent	PendingIntent
      //   3	128	9	localParcel1	Parcel
      //   8	118	10	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	63	124	finally
      //   68	82	124	finally
      //   82	104	124	finally
      //   115	121	124	finally
    }
    
    /* Error */
    public void a(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, String paramString10, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 12
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 13
      //   10: aload 12
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 12
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 12
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 12
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 12
      //   37: aload 4
      //   39: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   42: aload 12
      //   44: aload 5
      //   46: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   49: aload 12
      //   51: aload 6
      //   53: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   56: aload 12
      //   58: aload 7
      //   60: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   63: aload 12
      //   65: aload 8
      //   67: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   70: aload 12
      //   72: aload 9
      //   74: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   77: aload 12
      //   79: aload 10
      //   81: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   84: aload 11
      //   86: ifnull +50 -> 136
      //   89: aload 12
      //   91: iconst_1
      //   92: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   95: aload 11
      //   97: aload 12
      //   99: iconst_0
      //   100: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   103: aload_0
      //   104: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   107: bipush 11
      //   109: aload 12
      //   111: aload 13
      //   113: iconst_0
      //   114: invokeinterface 48 5 0
      //   119: pop
      //   120: aload 13
      //   122: invokevirtual 51	android/os/Parcel:readException	()V
      //   125: aload 13
      //   127: invokevirtual 58	android/os/Parcel:recycle	()V
      //   130: aload 12
      //   132: invokevirtual 58	android/os/Parcel:recycle	()V
      //   135: return
      //   136: aload 12
      //   138: iconst_0
      //   139: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   142: goto -39 -> 103
      //   145: astore_1
      //   146: aload 13
      //   148: invokevirtual 58	android/os/Parcel:recycle	()V
      //   151: aload 12
      //   153: invokevirtual 58	android/os/Parcel:recycle	()V
      //   156: aload_1
      //   157: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	158	0	this	a
      //   0	158	1	paramString1	String
      //   0	158	2	paramString2	String
      //   0	158	3	paramString3	String
      //   0	158	4	paramString4	String
      //   0	158	5	paramString5	String
      //   0	158	6	paramString6	String
      //   0	158	7	paramString7	String
      //   0	158	8	paramString8	String
      //   0	158	9	paramString9	String
      //   0	158	10	paramString10	String
      //   0	158	11	paramPendingIntent	PendingIntent
      //   3	149	12	localParcel1	Parcel
      //   8	139	13	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	84	145	finally
      //   89	103	145	finally
      //   103	125	145	finally
      //   136	142	145	finally
    }
    
    public byte[] a(String paramString1, byte[] paramArrayOfByte, String paramString2, String paramString3, long paramLong)
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.meizu.interfaces.IMzSnsService");
        localParcel1.writeString(paramString1);
        localParcel1.writeByteArray(paramArrayOfByte);
        localParcel1.writeString(paramString2);
        localParcel1.writeString(paramString3);
        localParcel1.writeLong(paramLong);
        a.transact(5, localParcel1, localParcel2, 0);
        localParcel2.readException();
        paramString1 = localParcel2.createByteArray();
        return paramString1;
      }
      finally
      {
        localParcel2.recycle();
        localParcel1.recycle();
      }
    }
    
    public String[] a(String paramString1, String paramString2, String paramString3, long paramLong)
    {
      Parcel localParcel1 = Parcel.obtain();
      Parcel localParcel2 = Parcel.obtain();
      try
      {
        localParcel1.writeInterfaceToken("com.meizu.interfaces.IMzSnsService");
        localParcel1.writeString(paramString1);
        localParcel1.writeString(paramString2);
        localParcel1.writeString(paramString3);
        localParcel1.writeLong(paramLong);
        a.transact(14, localParcel1, localParcel2, 0);
        localParcel2.readException();
        paramString1 = localParcel2.createStringArray();
        return paramString1;
      }
      finally
      {
        localParcel2.recycle();
        localParcel1.recycle();
      }
    }
    
    public IBinder asBinder()
    {
      return a;
    }
    
    /* Error */
    public void b(String paramString1, String paramString2, String paramString3, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 5
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 6
      //   10: aload 5
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 5
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 5
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 5
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 4
      //   37: ifnull +50 -> 87
      //   40: aload 5
      //   42: iconst_1
      //   43: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   46: aload 4
      //   48: aload 5
      //   50: iconst_0
      //   51: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   54: aload_0
      //   55: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   58: bipush 13
      //   60: aload 5
      //   62: aload 6
      //   64: iconst_0
      //   65: invokeinterface 48 5 0
      //   70: pop
      //   71: aload 6
      //   73: invokevirtual 51	android/os/Parcel:readException	()V
      //   76: aload 6
      //   78: invokevirtual 58	android/os/Parcel:recycle	()V
      //   81: aload 5
      //   83: invokevirtual 58	android/os/Parcel:recycle	()V
      //   86: return
      //   87: aload 5
      //   89: iconst_0
      //   90: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   93: goto -39 -> 54
      //   96: astore_1
      //   97: aload 6
      //   99: invokevirtual 58	android/os/Parcel:recycle	()V
      //   102: aload 5
      //   104: invokevirtual 58	android/os/Parcel:recycle	()V
      //   107: aload_1
      //   108: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	109	0	this	a
      //   0	109	1	paramString1	String
      //   0	109	2	paramString2	String
      //   0	109	3	paramString3	String
      //   0	109	4	paramPendingIntent	PendingIntent
      //   3	100	5	localParcel1	Parcel
      //   8	90	6	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	35	96	finally
      //   40	54	96	finally
      //   54	76	96	finally
      //   87	93	96	finally
    }
    
    /* Error */
    public void b(String paramString1, String paramString2, String paramString3, String paramString4, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 6
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 7
      //   10: aload 6
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 6
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 6
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 6
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 6
      //   37: aload 4
      //   39: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   42: aload 5
      //   44: ifnull +50 -> 94
      //   47: aload 6
      //   49: iconst_1
      //   50: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   53: aload 5
      //   55: aload 6
      //   57: iconst_0
      //   58: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   61: aload_0
      //   62: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   65: bipush 9
      //   67: aload 6
      //   69: aload 7
      //   71: iconst_0
      //   72: invokeinterface 48 5 0
      //   77: pop
      //   78: aload 7
      //   80: invokevirtual 51	android/os/Parcel:readException	()V
      //   83: aload 7
      //   85: invokevirtual 58	android/os/Parcel:recycle	()V
      //   88: aload 6
      //   90: invokevirtual 58	android/os/Parcel:recycle	()V
      //   93: return
      //   94: aload 6
      //   96: iconst_0
      //   97: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   100: goto -39 -> 61
      //   103: astore_1
      //   104: aload 7
      //   106: invokevirtual 58	android/os/Parcel:recycle	()V
      //   109: aload 6
      //   111: invokevirtual 58	android/os/Parcel:recycle	()V
      //   114: aload_1
      //   115: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	116	0	this	a
      //   0	116	1	paramString1	String
      //   0	116	2	paramString2	String
      //   0	116	3	paramString3	String
      //   0	116	4	paramString4	String
      //   0	116	5	paramPendingIntent	PendingIntent
      //   3	107	6	localParcel1	Parcel
      //   8	97	7	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	42	103	finally
      //   47	61	103	finally
      //   61	83	103	finally
      //   94	100	103	finally
    }
    
    /* Error */
    public void b(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, PendingIntent paramPendingIntent)
    {
      // Byte code:
      //   0: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   3: astore 9
      //   5: invokestatic 25	android/os/Parcel:obtain	()Landroid/os/Parcel;
      //   8: astore 10
      //   10: aload 9
      //   12: ldc 27
      //   14: invokevirtual 31	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
      //   17: aload 9
      //   19: aload_1
      //   20: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   23: aload 9
      //   25: aload_2
      //   26: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   29: aload 9
      //   31: aload_3
      //   32: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   35: aload 9
      //   37: aload 4
      //   39: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   42: aload 9
      //   44: aload 5
      //   46: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   49: aload 9
      //   51: aload 6
      //   53: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   56: aload 9
      //   58: aload 7
      //   60: invokevirtual 34	android/os/Parcel:writeString	(Ljava/lang/String;)V
      //   63: aload 8
      //   65: ifnull +50 -> 115
      //   68: aload 9
      //   70: iconst_1
      //   71: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   74: aload 8
      //   76: aload 9
      //   78: iconst_0
      //   79: invokevirtual 65	android/app/PendingIntent:writeToParcel	(Landroid/os/Parcel;I)V
      //   82: aload_0
      //   83: getfield 17	aiv$a$a:a	Landroid/os/IBinder;
      //   86: bipush 10
      //   88: aload 9
      //   90: aload 10
      //   92: iconst_0
      //   93: invokeinterface 48 5 0
      //   98: pop
      //   99: aload 10
      //   101: invokevirtual 51	android/os/Parcel:readException	()V
      //   104: aload 10
      //   106: invokevirtual 58	android/os/Parcel:recycle	()V
      //   109: aload 9
      //   111: invokevirtual 58	android/os/Parcel:recycle	()V
      //   114: return
      //   115: aload 9
      //   117: iconst_0
      //   118: invokevirtual 42	android/os/Parcel:writeInt	(I)V
      //   121: goto -39 -> 82
      //   124: astore_1
      //   125: aload 10
      //   127: invokevirtual 58	android/os/Parcel:recycle	()V
      //   130: aload 9
      //   132: invokevirtual 58	android/os/Parcel:recycle	()V
      //   135: aload_1
      //   136: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	137	0	this	a
      //   0	137	1	paramString1	String
      //   0	137	2	paramString2	String
      //   0	137	3	paramString3	String
      //   0	137	4	paramString4	String
      //   0	137	5	paramString5	String
      //   0	137	6	paramString6	String
      //   0	137	7	paramString7	String
      //   0	137	8	paramPendingIntent	PendingIntent
      //   3	128	9	localParcel1	Parcel
      //   8	118	10	localParcel2	Parcel
      // Exception table:
      //   from	to	target	type
      //   10	63	124	finally
      //   68	82	124	finally
      //   82	104	124	finally
      //   115	121	124	finally
    }
  }
}

/* Location:
 * Qualified Name:     aiv.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */