public class aii$b
  extends aif.a
{
  public long f;
  public String g;
  public String h;
  public String i;
  public String j;
  public CharSequence k;
  public aii.c l;
  
  public aii$b(aii paramaii)
  {
    super(false, false);
  }
}

/* Location:
 * Qualified Name:     aii.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */