import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class akt
  implements DialogInterface.OnClickListener
{
  akt(aks paramaks, aks.a parama) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    a.g.a(aks.a.a.a.a);
  }
}

/* Location:
 * Qualified Name:     akt
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */