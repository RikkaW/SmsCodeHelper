import android.os.Bundle;

class alq
  implements Runnable
{
  alq(alp paramalp, int paramInt, Bundle paramBundle) {}
  
  public void run()
  {
    alo.a(c.a, a, b);
  }
}

/* Location:
 * Qualified Name:     alq
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */