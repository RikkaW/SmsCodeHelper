import com.meizu.update.UpdateInfo;

public abstract interface akn
{
  public abstract void a(int paramInt, UpdateInfo paramUpdateInfo);
}

/* Location:
 * Qualified Name:     akn
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */