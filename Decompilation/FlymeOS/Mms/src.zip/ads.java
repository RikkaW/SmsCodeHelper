import com.android.mms.view.MessageListItemSms;
import com.android.mms.view.MessageListItemSms.a;
import org.json.JSONArray;

class ads
  implements Runnable
{
  ads(adr paramadr, Object[] paramArrayOfObject) {}
  
  public void run()
  {
    MessageListItemSms.a(b.b, new MessageListItemSms.a(b.b, Long.valueOf(b.a.e), (JSONArray)a[1]));
    if ((MessageListItemSms.b(b.b) != null) && (bb.b).g > 0))
    {
      b.b.a(MessageListItemSms.b(b.b));
      return;
    }
    b.b.z();
  }
}

/* Location:
 * Qualified Name:     ads
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */