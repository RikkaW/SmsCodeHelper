public class aly
  extends Exception
{
  public aly(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     aly
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */