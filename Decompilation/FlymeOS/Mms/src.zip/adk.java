import com.android.mms.view.MessageListItemBase;

public class adk
  implements Runnable
{
  public adk(MessageListItemBase paramMessageListItemBase, vv paramvv) {}
  
  public void run()
  {
    zn.a().b(a.t, 131, a.T);
  }
}

/* Location:
 * Qualified Name:     adk
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */