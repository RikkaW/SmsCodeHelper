public class afm
  extends afr
{
  public afm() {}
  
  public afm(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     afm
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */