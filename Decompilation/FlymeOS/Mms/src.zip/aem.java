class aem
  implements Runnable
{
  aem(ael paramael) {}
  
  public void run()
  {
    ael.a(ael.a(a), ael.b(a));
  }
}

/* Location:
 * Qualified Name:     aem
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */