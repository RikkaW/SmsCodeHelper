public class ame
  extends Exception
{
  private int a;
  
  public ame(int paramInt, String paramString)
  {
    super(paramString);
    a = paramInt;
  }
}

/* Location:
 * Qualified Name:     ame
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */