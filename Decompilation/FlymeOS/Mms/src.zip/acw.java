import com.android.mms.view.ConversationListItem;

public class acw
  implements Runnable
{
  public acw(ConversationListItem paramConversationListItem) {}
  
  public void run()
  {
    ConversationListItem.a(a, false);
  }
}

/* Location:
 * Qualified Name:     acw
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */