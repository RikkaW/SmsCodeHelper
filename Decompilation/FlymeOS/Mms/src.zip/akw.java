import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;

class akw
  implements DialogInterface.OnCancelListener
{
  akw(aks paramaks, aks.a parama) {}
  
  public void onCancel(DialogInterface paramDialogInterface)
  {
    a.g.a(aks.a.a.a.d);
  }
}

/* Location:
 * Qualified Name:     akw
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */