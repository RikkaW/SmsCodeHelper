import android.content.Context;

public class akl
{
  private akj a;
  
  public akl(Context paramContext, akn paramakn, long paramLong)
  {
    a = new akj(paramContext, paramakn, paramLong);
  }
  
  public void a(boolean paramBoolean)
  {
    new Thread(new akm(this, paramBoolean)).start();
  }
}

/* Location:
 * Qualified Name:     akl
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */