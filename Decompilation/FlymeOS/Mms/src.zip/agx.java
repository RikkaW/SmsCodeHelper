import android.location.Location;

public final class agx
{
  agy a = new agy(null);
  Location b;
  
  protected agx(agt paramagt) {}
}

/* Location:
 * Qualified Name:     agx
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */