class acq
  implements Runnable
{
  acq(aco paramaco) {}
  
  public void run()
  {
    if ((aco.a(a) != null) && (aco.b(a)) && (aco.c(a))) {
      aco.d(a);
    }
  }
}

/* Location:
 * Qualified Name:     acq
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */