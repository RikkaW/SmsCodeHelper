import android.location.Location;

public final class afw
{
  protected static afv a(Location paramLocation, agf paramagf, int paramInt, byte paramByte, long paramLong, boolean paramBoolean)
  {
    return agc.a(paramLocation, paramagf, paramInt, paramByte, paramLong, paramBoolean);
  }
}

/* Location:
 * Qualified Name:     afw
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */