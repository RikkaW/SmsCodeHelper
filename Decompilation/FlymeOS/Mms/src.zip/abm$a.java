import android.graphics.Bitmap;

public class abm$a
{
  public final Bitmap a;
  public final boolean b;
  
  public abm$a(Bitmap paramBitmap, boolean paramBoolean)
  {
    a = paramBitmap;
    b = paramBoolean;
  }
}

/* Location:
 * Qualified Name:     abm.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */