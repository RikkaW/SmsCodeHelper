import com.android.mms.view.MessageListItemBase;

public class adm
  implements Runnable
{
  public adm(MessageListItemBase paramMessageListItemBase, vv paramvv) {}
  
  public void run()
  {
    zn.a().a(a.t, 131, a.T);
  }
}

/* Location:
 * Qualified Name:     adm
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */