class ajn$b
{
  private String a;
  private String b;
  private long c;
  
  public ajn$b(String paramString1, String paramString2, long paramLong)
  {
    a = paramString1;
    b = paramString2;
    c = paramLong;
  }
  
  public String a()
  {
    return a;
  }
  
  public String b()
  {
    return b;
  }
  
  public long c()
  {
    return c;
  }
  
  public String toString()
  {
    return "{" + b + ", " + c + ", " + a + "}";
  }
}

/* Location:
 * Qualified Name:     ajn.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */