import android.support.v7.app.AlertDialog;

class acf
  implements Runnable
{
  acf(ace paramace, String paramString) {}
  
  public void run()
  {
    abu.d(b.b).setTitle(b.a + " - " + a);
  }
}

/* Location:
 * Qualified Name:     acf
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */