public final class agz
{
  String a = "";
  
  public agz(String paramString)
  {
    a = paramString;
  }
}

/* Location:
 * Qualified Name:     agz
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */