public final class aih$d
{
  public static final int input_email = 2131886132;
  public static final int input_phone = 2131886133;
  public static final int mz_recipient_add_btn = 2131886663;
  public static final int mz_recipient_edit = 2131886660;
  public static final int mz_recipient_hint = 2131886659;
  public static final int mz_recipient_hint2 = 2131886661;
  public static final int mz_recipient_layout = 2131886658;
  public static final int mz_recipient_name = 2131886662;
  public static final int mz_recipient_root = 2131886656;
  public static final int mz_recipient_scrollview = 2131886657;
  public static final int text = 2131886213;
}

/* Location:
 * Qualified Name:     aih.d
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */