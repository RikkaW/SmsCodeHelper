class amh$a
{
  public final String a;
  public final String b;
  
  public amh$a(String paramString1, String paramString2)
  {
    a = paramString1;
    b = paramString2;
  }
}

/* Location:
 * Qualified Name:     amh.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */