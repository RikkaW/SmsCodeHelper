import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

class akv
  implements DialogInterface.OnClickListener
{
  akv(aks paramaks, aks.a parama) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    a.g.a(aks.a.a.a.c);
  }
}

/* Location:
 * Qualified Name:     akv
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */