import android.support.v7.app.AlertDialog;

class acb
  implements Runnable
{
  acb(aca paramaca, String paramString) {}
  
  public void run()
  {
    abu.d(b.b).setTitle(b.a + " - " + a);
  }
}

/* Location:
 * Qualified Name:     acb
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */