import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;

class akx
  implements DialogInterface.OnDismissListener
{
  akx(aks paramaks) {}
  
  public void onDismiss(DialogInterface paramDialogInterface)
  {
    aks.a(a);
  }
}

/* Location:
 * Qualified Name:     akx
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */