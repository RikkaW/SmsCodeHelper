import android.app.PendingIntent;
import android.content.Context;
import com.amap.api.location.AMapLocation;
import org.json.JSONObject;

public abstract interface ahp
{
  public abstract ahf a();
  
  public abstract void a(aho paramaho, PendingIntent paramPendingIntent);
  
  public abstract void a(PendingIntent paramPendingIntent);
  
  public abstract void a(Context paramContext);
  
  public abstract void a(Context paramContext, AMapLocation paramAMapLocation);
  
  public abstract void a(String paramString);
  
  public abstract void a(JSONObject paramJSONObject);
  
  public abstract void b();
  
  public abstract void b(aho paramaho, PendingIntent paramPendingIntent);
  
  public abstract void b(PendingIntent paramPendingIntent);
}

/* Location:
 * Qualified Name:     ahp
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */