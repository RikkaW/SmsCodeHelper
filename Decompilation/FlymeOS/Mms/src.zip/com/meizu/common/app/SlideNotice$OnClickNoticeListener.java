package com.meizu.common.app;

public abstract interface SlideNotice$OnClickNoticeListener
{
  public abstract void onClick(SlideNotice paramSlideNotice);
}

/* Location:
 * Qualified Name:     com.meizu.common.app.SlideNotice.OnClickNoticeListener
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */