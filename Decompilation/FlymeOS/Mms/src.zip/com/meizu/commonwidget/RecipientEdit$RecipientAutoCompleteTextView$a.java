package com.meizu.commonwidget;

import android.view.KeyEvent;
import android.view.View;

public abstract interface RecipientEdit$RecipientAutoCompleteTextView$a
{
  public abstract boolean a(View paramView, int paramInt, KeyEvent paramKeyEvent);
}

/* Location:
 * Qualified Name:     com.meizu.commonwidget.RecipientEdit.RecipientAutoCompleteTextView.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */