package com.android.mms;

public abstract interface MmsApp$e
{
  public abstract int a();
  
  public abstract boolean b();
  
  public abstract void c();
  
  public abstract void d();
}

/* Location:
 * Qualified Name:     com.android.mms.MmsApp.e
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */