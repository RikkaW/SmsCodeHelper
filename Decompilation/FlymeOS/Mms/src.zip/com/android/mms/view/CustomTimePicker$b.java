package com.android.mms.view;

public abstract interface CustomTimePicker$b
{
  public abstract void a(int[] paramArrayOfInt);
}

/* Location:
 * Qualified Name:     com.android.mms.view.CustomTimePicker.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */