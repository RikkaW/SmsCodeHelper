package com.android.mms.view;

public abstract interface MmsFoldableTextView$a
{
  public abstract boolean a(MmsFoldableTextView paramMmsFoldableTextView);
}

/* Location:
 * Qualified Name:     com.android.mms.view.MmsFoldableTextView.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */