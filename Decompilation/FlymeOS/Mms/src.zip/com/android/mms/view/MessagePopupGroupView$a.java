package com.android.mms.view;

import android.content.res.Configuration;

public abstract interface MessagePopupGroupView$a
{
  public abstract int a();
  
  public abstract void a(float paramFloat);
  
  public abstract void a(Configuration paramConfiguration);
  
  public abstract int b();
  
  public abstract void b(float paramFloat);
  
  public abstract float c();
  
  public abstract void c(float paramFloat);
  
  public abstract float d();
  
  public abstract void e();
  
  public abstract void f();
}

/* Location:
 * Qualified Name:     com.android.mms.view.MessagePopupGroupView.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */