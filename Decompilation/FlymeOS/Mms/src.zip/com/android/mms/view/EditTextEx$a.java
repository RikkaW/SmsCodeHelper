package com.android.mms.view;

import android.os.Bundle;

public abstract interface EditTextEx$a
{
  public abstract boolean a(String paramString, Bundle paramBundle);
}

/* Location:
 * Qualified Name:     com.android.mms.view.EditTextEx.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */