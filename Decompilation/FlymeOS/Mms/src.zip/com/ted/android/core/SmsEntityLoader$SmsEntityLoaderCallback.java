package com.ted.android.core;

import com.ted.android.data.SmsEntity;

public abstract interface SmsEntityLoader$SmsEntityLoaderCallback
{
  public abstract void onSmsEntityLoaded(Long paramLong, SmsEntity paramSmsEntity);
}

/* Location:
 * Qualified Name:     com.ted.android.core.SmsEntityLoader.SmsEntityLoaderCallback
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */