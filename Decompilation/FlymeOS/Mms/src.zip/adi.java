import com.android.mms.view.MessageListItem;

public class adi
  implements vr.a
{
  public adi(MessageListItem paramMessageListItem, vv paramvv, boolean paramBoolean) {}
  
  public void a(int paramInt)
  {
    c.a(a, 2, b, paramInt);
  }
}

/* Location:
 * Qualified Name:     adi
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */