import com.android.mms.view.MessageListItem;

public class ade
  implements vv.d
{
  public ade(MessageListItem paramMessageListItem) {}
  
  public void a(vv paramvv)
  {
    if ((paramvv != null) && (a.M != null) && (paramvv.M() == a.M.M()))
    {
      a.M.a(null);
      a.s();
    }
  }
}

/* Location:
 * Qualified Name:     ade
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */