public class af
{
  public static b a = aux.b;
}

/* Location:
 * Qualified Name:     af
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */