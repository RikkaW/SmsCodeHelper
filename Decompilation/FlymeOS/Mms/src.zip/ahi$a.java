public abstract interface ahi$a
{
  public abstract void a(int paramInt);
}

/* Location:
 * Qualified Name:     ahi.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */