public abstract interface afb
{
  public abstract void a();
  
  public abstract void a(afj paramafj);
  
  public abstract void b();
  
  public abstract void c();
  
  public abstract void d();
}

/* Location:
 * Qualified Name:     afb
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */