class ajm
  implements Runnable
{
  ajm(ajl paramajl) {}
  
  public void run()
  {
    ajl.a(a);
  }
}

/* Location:
 * Qualified Name:     ajm
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */