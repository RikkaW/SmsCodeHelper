import android.app.Activity;

public class ako
{
  public static final void a(Activity paramActivity)
  {
    akd.a(paramActivity);
  }
  
  public static final void b(Activity paramActivity)
  {
    akd.b(paramActivity);
  }
}

/* Location:
 * Qualified Name:     ako
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */