import android.net.Uri;
import com.android.mms.view.MessageListItemTalk;

public class adv
  implements ach.a
{
  public adv(MessageListItemTalk paramMessageListItemTalk) {}
  
  public void a(Uri paramUri)
  {
    if ((a.M != null) && (paramUri != null) && (paramUri.equals(a.M.t))) {
      MessageListItemTalk.a(a, true);
    }
  }
  
  public void b(Uri paramUri)
  {
    if ((a.M != null) && (paramUri != null) && (paramUri.equals(a.M.t))) {
      MessageListItemTalk.a(a, false);
    }
  }
  
  public void c(Uri paramUri)
  {
    if ((a.M != null) && (paramUri != null) && (paramUri.equals(a.M.t))) {
      MessageListItemTalk.a(a, false);
    }
  }
}

/* Location:
 * Qualified Name:     adv
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */