import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.util.Log;

class acj
  implements MediaPlayer.OnCompletionListener
{
  acj(ach paramach) {}
  
  public void onCompletion(MediaPlayer paramMediaPlayer)
  {
    Log.d("VoicePlayer", "doPlay():stop()~~~~");
    ach.c(a);
  }
}

/* Location:
 * Qualified Name:     acj
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */