import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.android.mms.view.MessagePopupGroupView.a;

class aeh
  extends AnimatorListenerAdapter
{
  aeh(aee paramaee, MessagePopupGroupView.a parama) {}
  
  public void onAnimationEnd(Animator paramAnimator)
  {
    a.c(1.0F);
  }
}

/* Location:
 * Qualified Name:     aeh
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */