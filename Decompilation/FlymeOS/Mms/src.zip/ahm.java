import java.util.concurrent.Callable;

class ahm
  implements Callable<Void>
{
  ahm(ahl paramahl) {}
  
  public Void a()
  {
    synchronized (a)
    {
      if (ahl.a(a) == null) {
        return null;
      }
      ahl.b(a);
      if (ahl.c(a))
      {
        ahl.d(a);
        ahl.a(a, 0);
      }
      return null;
    }
  }
}

/* Location:
 * Qualified Name:     ahm
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */