import android.app.AlertDialog;

public class aln
  implements akg
{
  private final AlertDialog a;
  private final boolean b;
  private final boolean c;
  
  public aln(AlertDialog paramAlertDialog, boolean paramBoolean1, boolean paramBoolean2)
  {
    a = paramAlertDialog;
    b = paramBoolean1;
    c = paramBoolean2;
  }
}

/* Location:
 * Qualified Name:     aln
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */