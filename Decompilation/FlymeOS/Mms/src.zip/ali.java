import android.content.Context;

class ali
  implements Runnable
{
  ali(ald paramald) {}
  
  public void run()
  {
    anm.a(a.a, a.a.getString(akq.d.mzuc_install_cancel_tip), new alj(this), new alk(this));
  }
}

/* Location:
 * Qualified Name:     ali
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */