package cn.com.xy.sms.util;

import cn.com.xy.sms.sdk.Iservice.XyCallBack;

public abstract interface SdkCallBack
  extends XyCallBack
{}

/* Location:
 * Qualified Name:     cn.com.xy.sms.util.SdkCallBack
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */