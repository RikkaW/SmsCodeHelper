package cn.com.xy.sms.sdk.Iservice;

public abstract interface XyCallBack
{
  public abstract void execute(Object... paramVarArgs);
}

/* Location:
 * Qualified Name:     cn.com.xy.sms.sdk.Iservice.XyCallBack
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */