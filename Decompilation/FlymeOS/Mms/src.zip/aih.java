public final class aih
{
  public static final class a
  {
    public static final int mw_recipient_text_addrecipient_easymode = 2131820746;
    public static final int mw_recipient_text_black = 2131820747;
    public static final int mw_recipient_text_blue = 2131820748;
    public static final int mw_recipient_text_gray = 2131820749;
    public static final int mw_recipient_text_green = 2131820750;
    public static final int mw_recipient_text_invalidate = 2131820751;
    public static final int mw_recipient_text_invalidate_calendar = 2131820752;
    public static final int mw_recipient_text_red = 2131820753;
    public static final int mw_recipient_text_white = 2131820754;
  }
  
  public static final class b
  {
    public static final int activity_horizontal_margin = 2131558557;
    public static final int activity_vertical_margin = 2131558625;
    public static final int mw_recipient_btn_padding = 2131559381;
    public static final int mw_recipient_btn_padding_bottom = 2131559382;
    public static final int mw_recipient_btn_padding_top = 2131559383;
    public static final int mw_recipient_hint2_padding_right = 2131559384;
    public static final int mw_recipient_hint_padding_right = 2131559385;
    public static final int mw_recipient_layout_padding_bottom = 2131559386;
    public static final int mw_recipient_layout_padding_top = 2131559387;
    public static final int mw_recipient_list_item_height = 2131559388;
    public static final int mw_recipient_list_item_padding_left = 2131559389;
    public static final int mw_recipient_list_item_padding_right = 2131559390;
    public static final int mw_recipient_max_height = 2131559391;
    public static final int mw_recipient_min_height = 2131559392;
    public static final int mw_recipient_padding_left = 2131559393;
    public static final int mw_recipient_padding_right = 2131559394;
    public static final int mw_recipient_text_padding = 2131559395;
    public static final int mw_recipient_text_paddingtop = 2131559396;
    public static final int mw_recipient_text_size = 2131559397;
    public static final int mw_recipient_text_size_easymode = 2131559398;
    public static final int mw_recipient_total_padding_right = 2131559399;
  }
  
  public static final class c
  {
    public static final int mw_btn_list_add = 2130837958;
    public static final int mw_btn_list_add_normal = 2130837959;
    public static final int mw_btn_list_add_pressed = 2130837960;
    public static final int mw_ic_list_delete_contact = 2130837961;
    public static final int mw_ic_list_global_contact = 2130837962;
    public static final int mw_ic_list_sns_sina_weibo = 2130837963;
    public static final int mw_list_divider_light = 2130837964;
    public static final int mw_list_history_background = 2130837965;
    public static final int mw_list_history_background_noshadow = 2130837966;
    public static final int mw_recipient_divider_email_2px = 2130837967;
    public static final int mw_recipient_divider_sms_2px = 2130837968;
    public static final int mw_recipient_selected_bg = 2130837969;
    public static final int mw_recipient_selected_bg_calendar = 2130837970;
    public static final int mw_recipient_selected_bg_easymode = 2130837971;
    public static final int mw_recipient_selected_bg_mns = 2130837972;
    public static final int mw_recipient_text = 2130837973;
    public static final int mw_recipient_text_calendar = 2130837974;
    public static final int mw_recipient_text_easymode = 2130837975;
    public static final int mw_recipient_text_mns = 2130837976;
    public static final int mw_recipient_textcolor = 2130837977;
    public static final int mw_recipient_textcolor_calendar = 2130837978;
    public static final int mw_recipient_textcolor_easymode = 2130837979;
    public static final int mw_recipient_textcolor_mns = 2130837980;
    public static final int mw_scrollbar_handle_vertical = 2130837981;
  }
  
  public static final class d
  {
    public static final int input_email = 2131886132;
    public static final int input_phone = 2131886133;
    public static final int mz_recipient_add_btn = 2131886663;
    public static final int mz_recipient_edit = 2131886660;
    public static final int mz_recipient_hint = 2131886659;
    public static final int mz_recipient_hint2 = 2131886661;
    public static final int mz_recipient_layout = 2131886658;
    public static final int mz_recipient_name = 2131886662;
    public static final int mz_recipient_root = 2131886656;
    public static final int mz_recipient_scrollview = 2131886657;
    public static final int text = 2131886213;
  }
  
  public static final class e
  {
    public static final int mw_recipient_edit_layout = 2130968768;
    public static final int mw_recipient_edit_layout_easymode = 2130968769;
    public static final int mw_recipient_itemview = 2130968770;
    public static final int mw_recipient_itemview_calendar = 2130968771;
    public static final int mw_recipient_itemview_easymode = 2130968772;
    public static final int mw_recipient_itemview_mns = 2130968773;
    public static final int mw_recipient_list_item = 2130968774;
    public static final int mw_recipient_list_loading = 2130968775;
  }
  
  public static final class f
  {
    public static final int mw_recipient_addrecipient_easymode = 2131493850;
    public static final int mw_recipient_edit_imeActionLabel = 2131493744;
    public static final int mw_recipient_global_search = 2131493745;
    public static final int mw_recipient_global_searching = 2131493746;
    public static final int mw_recipient_hint_str = 2131493747;
    public static final int mw_recipient_others_displayname = 2131493748;
    public static final int mw_recipient_sns_search = 2131493749;
    public static final int mw_recipient_sns_searching = 2131493750;
    public static final int mw_recipient_sns_update = 2131493751;
    public static final int mw_recipient_sns_updating = 2131493752;
    public static final int mw_recipient_title = 2131493753;
    public static final int mw_recipient_title_email = 2131493754;
    public static final int mw_recipient_title_message = 2131493755;
    public static final int mw_recipient_total_str = 2131493756;
  }
  
  public static final class g
  {
    public static final int[] RecipientEdit = { 2130772272, 2130772273, 2130772274, 2130772275 };
    public static final int RecipientEdit_isEasyMode = 3;
    public static final int RecipientEdit_mzHint = 1;
    public static final int RecipientEdit_mzInputType = 0;
    public static final int RecipientEdit_mzMaxHeight = 2;
  }
}

/* Location:
 * Qualified Name:     aih
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */