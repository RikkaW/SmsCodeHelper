import com.android.mms.ui.ComposeMessageActivity;
import com.android.mms.view.MessageListItemBase;

public class ado
  implements Runnable
{
  public ado(MessageListItemBase paramMessageListItemBase) {}
  
  public void run()
  {
    ((ComposeMessageActivity)a.U).a(a);
  }
}

/* Location:
 * Qualified Name:     ado
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */