import java.io.Serializable;

final class aid
  implements Serializable
{
  protected short a = 0;
  protected int b = 0;
  protected afu c = null;
  protected aib d = null;
  protected agd e = null;
  protected afz f = null;
  protected afx g = null;
}

/* Location:
 * Qualified Name:     aid
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */