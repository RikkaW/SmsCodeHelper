import android.os.Handler;
import android.os.Message;

final class ago
  extends Handler
{
  ago(agn paramagn) {}
  
  public final void handleMessage(Message paramMessage)
  {
    try
    {
      switch (what)
      {
      case 1: 
        if (aie.d(a.a) != null)
        {
          aie.d(a.a).a((String)obj);
          return;
        }
        break;
      }
    }
    catch (Exception paramMessage) {}
  }
}

/* Location:
 * Qualified Name:     ago
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */