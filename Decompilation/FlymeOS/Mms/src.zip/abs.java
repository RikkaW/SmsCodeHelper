import com.android.mms.view.CustomTimePicker.b;

public final class abs
  implements CustomTimePicker.b
{
  public abs(Runnable paramRunnable) {}
  
  public void a(int[] paramArrayOfInt)
  {
    a.run();
  }
}

/* Location:
 * Qualified Name:     abs
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */