public class afp
  extends afn
{
  public afp() {}
  
  public afp(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     afp
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */