public final class aih$c
{
  public static final int mw_btn_list_add = 2130837958;
  public static final int mw_btn_list_add_normal = 2130837959;
  public static final int mw_btn_list_add_pressed = 2130837960;
  public static final int mw_ic_list_delete_contact = 2130837961;
  public static final int mw_ic_list_global_contact = 2130837962;
  public static final int mw_ic_list_sns_sina_weibo = 2130837963;
  public static final int mw_list_divider_light = 2130837964;
  public static final int mw_list_history_background = 2130837965;
  public static final int mw_list_history_background_noshadow = 2130837966;
  public static final int mw_recipient_divider_email_2px = 2130837967;
  public static final int mw_recipient_divider_sms_2px = 2130837968;
  public static final int mw_recipient_selected_bg = 2130837969;
  public static final int mw_recipient_selected_bg_calendar = 2130837970;
  public static final int mw_recipient_selected_bg_easymode = 2130837971;
  public static final int mw_recipient_selected_bg_mns = 2130837972;
  public static final int mw_recipient_text = 2130837973;
  public static final int mw_recipient_text_calendar = 2130837974;
  public static final int mw_recipient_text_easymode = 2130837975;
  public static final int mw_recipient_text_mns = 2130837976;
  public static final int mw_recipient_textcolor = 2130837977;
  public static final int mw_recipient_textcolor_calendar = 2130837978;
  public static final int mw_recipient_textcolor_easymode = 2130837979;
  public static final int mw_recipient_textcolor_mns = 2130837980;
  public static final int mw_scrollbar_handle_vertical = 2130837981;
}

/* Location:
 * Qualified Name:     aih.c
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */