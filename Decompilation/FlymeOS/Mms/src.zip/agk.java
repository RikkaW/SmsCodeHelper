import android.net.wifi.WifiManager;
import java.util.TimerTask;

final class agk
  extends TimerTask
{
  agk(agj paramagj) {}
  
  public final void run()
  {
    try
    {
      if ((ahb.a) && (agf.c(a.a) != null)) {
        agf.c(a.a).startScan();
      }
      return;
    }
    catch (Exception localException) {}
  }
}

/* Location:
 * Qualified Name:     agk
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */