public abstract interface gm$b
{
  public abstract void a(gm paramgm);
}

/* Location:
 * Qualified Name:     gm.b
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */