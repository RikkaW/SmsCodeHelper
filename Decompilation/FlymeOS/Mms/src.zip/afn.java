public class afn
  extends Exception
{
  public afn() {}
  
  public afn(String paramString)
  {
    super(paramString);
  }
}

/* Location:
 * Qualified Name:     afn
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */