import com.android.mms.view.MessageListItemSms;

public class adt
  implements Runnable
{
  public adt(MessageListItemSms paramMessageListItemSms) {}
  
  public void run()
  {
    a.z();
  }
}

/* Location:
 * Qualified Name:     adt
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */