import android.os.Bundle;

class alp
  extends amt.a
{
  alp(alo paramalo) {}
  
  public void a(int paramInt, Bundle paramBundle) {}
  
  public void b(int paramInt, Bundle paramBundle)
  {
    alo.a(a, new alq(this, paramInt, paramBundle));
  }
}

/* Location:
 * Qualified Name:     alp
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */