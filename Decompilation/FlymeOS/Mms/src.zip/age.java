import java.io.Serializable;

final class age
  implements Serializable
{
  protected short a = 0;
  protected int b = 0;
  protected byte c = 0;
}

/* Location:
 * Qualified Name:     age
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */