import com.meizu.update.UpdateInfo;

class ala
  implements aks.a.a
{
  ala(akz paramakz) {}
  
  public void a(aks.a.a.a parama)
  {
    switch (akz.1.a[parama.ordinal()])
    {
    case 2: 
    default: 
      return;
    }
    and.a(a.a).a(and.a.g, a.b.mVersionName);
    akz.a(a);
  }
}

/* Location:
 * Qualified Name:     ala
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */