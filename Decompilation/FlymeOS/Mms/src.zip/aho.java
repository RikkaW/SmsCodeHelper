public class aho
{
  public double a = 0.0D;
  public double b = 0.0D;
  public float c = 0.0F;
  int d = -1;
  private long e = -1L;
  
  public long a()
  {
    return e;
  }
  
  public void a(long paramLong)
  {
    if (paramLong >= 0L)
    {
      e = (ahz.b() + paramLong);
      return;
    }
    e = paramLong;
  }
  
  public String b()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(a).append("#").append(b).append("#").append(c);
    return localStringBuilder.toString();
  }
}

/* Location:
 * Qualified Name:     aho
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */