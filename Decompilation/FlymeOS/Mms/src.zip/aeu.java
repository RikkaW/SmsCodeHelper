import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import com.android.mms.view.MzContactHeaderWidget;

public class aeu
  implements DialogInterface.OnClickListener
{
  public aeu(MzContactHeaderWidget paramMzContactHeaderWidget) {}
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt)
  {
    MzContactHeaderWidget.a(a, ((gm)a.b.get(paramInt)).d());
  }
}

/* Location:
 * Qualified Name:     aeu
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */