import android.net.Uri;

public class aam
  implements zz
{
  public void a(Uri paramUri) {}
  
  public void a(boolean paramBoolean) {}
  
  public boolean a()
  {
    return true;
  }
}

/* Location:
 * Qualified Name:     aam
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */