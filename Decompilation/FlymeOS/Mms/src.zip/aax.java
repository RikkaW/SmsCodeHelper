import android.net.Uri;
import android.telephony.SmsMessage;
import cn.com.xy.sms.sdk.ui.popu.util.XySdkUtil;

final class aax
  implements Runnable
{
  aax(Uri paramUri, SmsMessage[] paramArrayOfSmsMessage, int paramInt) {}
  
  public void run()
  {
    long l = Long.parseLong(a.getLastPathSegment());
    XySdkUtil.parseMsg(l + "", b, 0, c);
  }
}

/* Location:
 * Qualified Name:     aax
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */