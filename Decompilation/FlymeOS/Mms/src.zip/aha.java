import android.location.Location;
import java.util.ArrayList;
import java.util.List;

public final class aha
{
  List a = new ArrayList();
  Location b;
  
  protected aha(agt paramagt) {}
}

/* Location:
 * Qualified Name:     aha
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */