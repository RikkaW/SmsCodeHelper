import android.view.View;
import android.view.View.OnClickListener;
import com.android.mms.view.MmsRichContainer;

public class aen
  implements View.OnClickListener
{
  public aen(MmsRichContainer paramMmsRichContainer) {}
  
  public void onClick(View paramView)
  {
    a.a(false, 0);
  }
}

/* Location:
 * Qualified Name:     aen
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */