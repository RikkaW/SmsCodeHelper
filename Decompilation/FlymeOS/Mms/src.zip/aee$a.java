import com.android.mms.view.MessagePopupGroupView.a;

public abstract interface aee$a
{
  public abstract void a(MessagePopupGroupView.a parama);
  
  public abstract void b(MessagePopupGroupView.a parama);
  
  public abstract boolean b();
  
  public abstract void c();
  
  public abstract MessagePopupGroupView.a getAnimatorObject();
}

/* Location:
 * Qualified Name:     aee.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */