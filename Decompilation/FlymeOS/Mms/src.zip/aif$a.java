import android.database.Cursor;

public class aif$a
{
  boolean a;
  boolean b;
  Cursor c;
  int d;
  int e;
  
  public aif$a(boolean paramBoolean1, boolean paramBoolean2)
  {
    a = paramBoolean1;
    b = paramBoolean2;
  }
  
  public boolean a()
  {
    return b;
  }
}

/* Location:
 * Qualified Name:     aif.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */