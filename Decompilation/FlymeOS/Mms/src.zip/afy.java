import java.io.Serializable;

final class afy
  implements Serializable
{
  protected byte a = 0;
  protected byte[] b = new byte[100];
  protected double c = 0.0D;
  protected int d = 0;
  protected int e = 0;
  protected double f = 0.0D;
  protected byte g = 0;
  protected byte h = 0;
  protected byte[] i = new byte[100];
  protected byte j = 0;
}

/* Location:
 * Qualified Name:     afy
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */