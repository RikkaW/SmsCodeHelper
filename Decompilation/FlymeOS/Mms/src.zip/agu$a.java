class agu$a
  implements ahi.a
{
  agu$a(agu paramagu) {}
  
  public void a(int paramInt)
  {
    a.b = paramInt;
  }
}

/* Location:
 * Qualified Name:     agu.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */