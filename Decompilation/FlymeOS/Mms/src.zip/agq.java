public final class agq
  extends Thread
{
  public final void run()
  {
    try
    {
      while (aie.c(a))
      {
        aie.a(a, aie.g(a), 1, System.currentTimeMillis());
        try
        {
          Thread.sleep(aie.h(a));
        }
        catch (Exception localException1) {}
      }
      return;
    }
    catch (Exception localException2) {}
  }
}

/* Location:
 * Qualified Name:     agq
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */