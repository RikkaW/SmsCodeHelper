public final class akq$a
{
  public static final int mzuc_dialog_msg_text_color = 2131820821;
  public static final int mzuc_dialog_sub_title_text_color = 2131820822;
  public static final int mzuc_progress_bar_color = 2131820823;
}

/* Location:
 * Qualified Name:     akq.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */