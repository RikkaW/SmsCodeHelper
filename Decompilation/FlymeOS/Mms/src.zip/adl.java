import com.android.mms.view.MessageListItemBase;

public class adl
  implements Runnable
{
  public adl(MessageListItemBase paramMessageListItemBase, vv paramvv) {}
  
  public void run()
  {
    zn.a().a(a.t, 131, a.T);
  }
}

/* Location:
 * Qualified Name:     adl
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */