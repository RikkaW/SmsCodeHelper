import com.android.mms.view.MmsFoldableTextView;

class aca
  implements Runnable
{
  aca(abu paramabu, String paramString) {}
  
  public void run()
  {
    try
    {
      String str = abu.a(a, abu.c(b));
      if (str != null) {
        abu.e(b).post(new acb(this, str));
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:
 * Qualified Name:     aca
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */