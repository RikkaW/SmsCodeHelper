import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;

class aah
  implements Runnable
{
  aah(aad paramaad, int paramInt, Uri paramUri) {}
  
  public void run()
  {
    ContentValues localContentValues = new ContentValues(1);
    localContentValues.put("type", Integer.valueOf(a));
    aad.c(c).getContentResolver().update(b, localContentValues, null, null);
  }
}

/* Location:
 * Qualified Name:     aah
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */