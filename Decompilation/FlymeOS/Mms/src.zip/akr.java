import com.meizu.update.UpdateInfo;

public abstract interface akr
{
  public abstract void a(int paramInt, UpdateInfo paramUpdateInfo);
}

/* Location:
 * Qualified Name:     akr
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */