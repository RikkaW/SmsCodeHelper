import android.view.View;
import android.view.View.OnClickListener;
import com.android.mms.view.MzContactHeaderWidget;

public class aer
  implements View.OnClickListener
{
  public aer(MzContactHeaderWidget paramMzContactHeaderWidget) {}
  
  public void onClick(View paramView)
  {
    a.b();
  }
}

/* Location:
 * Qualified Name:     aer
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */