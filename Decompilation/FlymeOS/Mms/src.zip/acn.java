import android.media.MediaPlayer;
import android.media.MediaPlayer.OnErrorListener;
import android.util.Log;

class acn
  implements MediaPlayer.OnErrorListener
{
  acn(ach paramach) {}
  
  public boolean onError(MediaPlayer paramMediaPlayer, int paramInt1, int paramInt2)
  {
    Log.d("VoicePlayer", "setTreamType():onPlaybackError()~~~~");
    ach.d(a);
    return true;
  }
}

/* Location:
 * Qualified Name:     acn
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */