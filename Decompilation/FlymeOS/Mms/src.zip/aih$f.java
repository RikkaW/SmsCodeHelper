public final class aih$f
{
  public static final int mw_recipient_addrecipient_easymode = 2131493850;
  public static final int mw_recipient_edit_imeActionLabel = 2131493744;
  public static final int mw_recipient_global_search = 2131493745;
  public static final int mw_recipient_global_searching = 2131493746;
  public static final int mw_recipient_hint_str = 2131493747;
  public static final int mw_recipient_others_displayname = 2131493748;
  public static final int mw_recipient_sns_search = 2131493749;
  public static final int mw_recipient_sns_searching = 2131493750;
  public static final int mw_recipient_sns_update = 2131493751;
  public static final int mw_recipient_sns_updating = 2131493752;
  public static final int mw_recipient_title = 2131493753;
  public static final int mw_recipient_title_email = 2131493754;
  public static final int mw_recipient_title_message = 2131493755;
  public static final int mw_recipient_total_str = 2131493756;
}

/* Location:
 * Qualified Name:     aih.f
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */