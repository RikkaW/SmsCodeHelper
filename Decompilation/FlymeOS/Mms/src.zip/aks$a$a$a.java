public enum aks$a$a$a
{
  private aks$a$a$a() {}
}

/* Location:
 * Qualified Name:     aks.a.a.a
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */