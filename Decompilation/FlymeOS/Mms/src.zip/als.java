import android.content.Context;
import com.meizu.update.UpdateInfo;

class als
  implements aks.a.a
{
  als(alo paramalo) {}
  
  public void a(aks.a.a.a parama)
  {
    switch (alo.1.a[parama.ordinal()])
    {
    default: 
      return;
    case 1: 
      and.a(a.a).a(and.a.d, a.b.mVersionName, anl.b(a.a, a.a.getPackageName()), alo.b(a));
      alo.c(a);
      return;
    case 2: 
      and.a(a.a).a(and.a.e, a.b.mVersionName, anl.b(a.a, a.a.getPackageName()), alo.b(a));
      amx.b(a.a, a.b.mVersionName);
      alo.d(a);
      return;
    case 3: 
      and.a(a.a).a(and.a.f, a.b.mVersionName, anl.b(a.a, a.a.getPackageName()), alo.b(a));
      alo.d(a);
      return;
    }
    and.a(a.a).a(and.a.f, a.b.mVersionName, anl.b(a.a, a.a.getPackageName()), alo.b(a));
    akk.c(a.a);
    alo.d(a);
  }
}

/* Location:
 * Qualified Name:     als
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */