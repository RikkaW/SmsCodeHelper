import com.android.mms.view.MessageListItemTalk;

public class ady
  implements vv.d
{
  public ady(MessageListItemTalk paramMessageListItemTalk) {}
  
  public void a(vv paramvv)
  {
    if ((paramvv != null) && (a.M != null) && (paramvv.M() == a.M.M())) {
      a.a(a.M);
    }
  }
}

/* Location:
 * Qualified Name:     ady
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */