public class aii$d
  extends aif.a
{
  public aii$d(aii paramaii)
  {
    super(true, true);
  }
}

/* Location:
 * Qualified Name:     aii.d
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */