public class aix
{
  public int a;
  public int b;
  public int c;
  public int d;
}

/* Location:
 * Qualified Name:     aix
 * Java Class Version: 6 (50.0)
 * JD-Core Version:    0.7.1
 */